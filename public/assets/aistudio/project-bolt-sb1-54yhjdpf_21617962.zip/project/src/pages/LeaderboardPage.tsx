import { useState, useMemo } from 'react';
import { Trophy, TrendingUp, TrendingDown, Minus, Crown, Medal, Search, Gamepad2, ChevronDown, Flame, Crosshair } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { leaderboard, games } from '@/data/catalog';
import { useReveal } from '@/hooks/useMotion';

const trendIcon = { up: TrendingUp, down: TrendingDown, same: Minus };
const trendColor = { up: 'text-success-400', down: 'text-error-400', same: 'text-slate-500' };

const gameIconMap: Record<string, typeof Flame> = { flame: Flame, crosshair: Crosshair, football: Crosshair };

export default function LeaderboardPage() {
  const { ref, inView } = useReveal<HTMLDivElement>();
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<number | null>(null);

  const filtered = useMemo(() => {
    return leaderboard.filter((p) => {
      const matchGame = filter === 'all' || p.gameId === filter;
      const matchSearch = search.trim() === '' || p.player.toLowerCase().includes(search.toLowerCase());
      return matchGame && matchSearch;
    });
  }, [filter, search]);

  const podiumData = filtered.slice(0, 3);

  return (
    <div className="relative min-h-screen pt-20">
      <section className="relative overflow-hidden py-12">
        <div className="absolute inset-0 -z-10 bg-radial-fade" />
        <div className="container-x">
          <Reveal className="text-center">
            <span className="chip border-gold-400/30 bg-gold-400/10 text-gold-200"><Crown className="h-3.5 w-3.5" /> Hall of Fame</span>
            <h1 className="mt-4 font-display text-4xl font-bold text-white sm:text-5xl">Top <span className="text-gradient-gold">players</span></h1>
            <p className="mt-4 text-slate-400">Ranked by tournament performance and top-up loyalty points.</p>
          </Reveal>
        </div>
      </section>

      <section className="py-8">
        <div className="container-x">
          <Reveal>
            {/* Game filter tabs */}
            <div className="mb-4 flex flex-wrap items-center gap-2">
              <button
                onClick={() => setFilter('all')}
                className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all ${filter === 'all' ? 'border-primary-400/50 bg-primary-400/15 text-primary-300' : 'border-white/10 bg-white/5 text-slate-400 hover:text-white'}`}
              >
                <Gamepad2 className="h-3.5 w-3.5" /> All Games
              </button>
              {games.map((g) => {
                const Icon = gameIconMap[g.iconKey] ?? Gamepad2;
                return (
                  <button
                    key={g.id}
                    onClick={() => setFilter(g.id)}
                    className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all ${filter === g.id ? 'border-white/30 text-white' : 'border-white/10 bg-white/5 text-slate-400 hover:text-white'}`}
                    style={filter === g.id ? { background: `${g.accent}20`, borderColor: `${g.accent}55`, color: g.accent } : {}}
                  >
                    <Icon className="h-3.5 w-3.5" /> {g.name}
                  </button>
                );
              })}
              <div className="relative ml-auto">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search players..."
                  className="w-40 rounded-full border border-white/10 bg-ink-900/60 py-1.5 pl-9 pr-3 text-xs text-white placeholder:text-slate-600 focus:border-primary-400/50 focus:outline-none sm:w-56"
                />
              </div>
            </div>

            <div ref={ref} className="glass-strong overflow-hidden rounded-2xl">
              {/* Podium */}
              <div className="grid gap-4 p-6 sm:grid-cols-3">
                {podiumData.map((p, i) => {
                  const rank = i + 1;
                  const heights = ['h-28', 'h-20', 'h-16'];
                  const colors = ['from-gold-300 to-gold-500', 'from-slate-300 to-slate-500', 'from-accent-300 to-accent-600'];
                  const Icon = rank === 1 ? Crown : Medal;
                  return (
                    <div key={p.player} className={`flex flex-col items-center ${rank === 1 ? 'sm:-mt-6' : ''} ${inView ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: `${i * 120}ms` }}>
                      <div className="relative">
                        <div className="grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-primary-400/30 to-ink-700 font-display text-lg font-bold text-white">{p.player.slice(0, 2).toUpperCase()}</div>
                        <span className={`absolute -bottom-1 -right-1 grid h-6 w-6 place-items-center rounded-full bg-gradient-to-br ${colors[i]} text-xs font-bold text-ink-950`}>{rank}</span>
                      </div>
                      <p className="mt-2 text-sm font-semibold text-white">{p.player}</p>
                      <p className="text-xs text-slate-400">{p.game}</p>
                      <Icon className={`mt-2 h-5 w-5 ${rank === 1 ? 'text-gold-400' : 'text-slate-400'}`} />
                      <div className={`mt-2 flex ${heights[i]} w-full items-end justify-center rounded-t-lg bg-gradient-to-t ${colors[i]}`}>
                        <span className="mb-1 font-mono text-xs font-bold text-ink-950">{p.points.toLocaleString()}</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="divider-glow" />

              {/* Table */}
              {filtered.length === 0 ? (
                <div className="px-5 py-16 text-center">
                  <Search className="mx-auto h-8 w-8 text-slate-600" />
                  <p className="mt-3 text-sm font-medium text-slate-400">No players found</p>
                  <p className="mt-1 text-xs text-slate-500">Try a different search or game filter.</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {filtered.map((p) => {
                    const Trend = trendIcon[p.trend];
                    const isOpen = expanded === p.rank;
                    const winRate = Math.round((p.wins / p.matches) * 100);
                    return (
                      <div key={p.player}>
                        <button
                          onClick={() => setExpanded(isOpen ? null : p.rank)}
                          className="flex w-full items-center gap-4 px-5 py-3 text-left transition-colors hover:bg-white/[0.02]"
                        >
                          <span className="w-8 text-center font-mono text-sm font-bold text-slate-400">#{p.rank}</span>
                          <div className="grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-primary-400/20 to-ink-700 text-xs font-bold text-white">{p.player.slice(0, 2).toUpperCase()}</div>
                          <div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-white">{p.player}</p><p className="text-xs text-slate-500">{p.game}</p></div>
                          <Trend className={`h-4 w-4 ${trendColor[p.trend]}`} />
                          <span className="w-24 text-right font-mono text-sm font-bold text-gold-300">{p.points.toLocaleString()}</span>
                          <ChevronDown className={`h-4 w-4 shrink-0 text-slate-500 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
                        </button>
                        {isOpen && (
                          <div className="grid gap-3 px-5 pb-5 pt-1 animate-fade-up sm:grid-cols-2 lg:grid-cols-4" style={{ animationDuration: '0.25s' }}>
                            <Stat label="Wins" value={p.wins.toString()} />
                            <Stat label="Matches" value={p.matches.toString()} />
                            <Stat label="Win Rate" value={`${winRate}%`} />
                            <Stat label={p.kd > 0 ? 'K/D Ratio' : 'Goals/Game'} value={p.kd > 0 ? p.kd.toFixed(1) : '2.3'} />
                            <div className="sm:col-span-2 lg:col-span-4 rounded-xl border border-white/10 bg-white/[0.02] p-4">
                              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Best Finish</p>
                              <p className="mt-1 text-sm font-medium text-white">{p.bestFinish}</p>
                              <p className="mt-3 text-xs font-semibold uppercase tracking-wider text-slate-500">Joined</p>
                              <p className="mt-1 text-sm text-slate-300">{p.joinedDate}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </Reveal>

          {/* Season info */}
          <Reveal delay={100} className="mt-6">
            <div className="glass rounded-2xl p-5 text-center">
              <Trophy className="mx-auto h-6 w-6 text-gold-400" />
              <p className="mt-2 font-display text-lg font-bold text-white">Season 4 — Ends December 31, 2026</p>
              <p className="mt-1 text-sm text-slate-400">Top 10 players qualify for the Grand Finals with a Br 100,000 prize pool.</p>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.02] p-3">
      <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{label}</p>
      <p className="mt-1 font-mono text-lg font-bold text-white">{value}</p>
    </div>
  );
}
