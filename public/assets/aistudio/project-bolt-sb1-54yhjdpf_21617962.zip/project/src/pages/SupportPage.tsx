import { useState } from 'react';
import { Headphones, ChevronDown, MessageCircle, Mail, Phone, MapPin, ShieldCheck } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { faqs } from '@/data/catalog';

export default function SupportPage() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <div className="relative min-h-screen pt-20">
      <section className="relative overflow-hidden py-12">
        <div className="absolute inset-0 -z-10 bg-radial-fade" />
        <div className="container-x">
          <Reveal className="text-center">
            <span className="chip border-primary-400/30 bg-primary-400/10 text-primary-200"><Headphones className="h-3.5 w-3.5" /> Support</span>
            <h1 className="mt-4 font-display text-4xl font-bold text-white sm:text-5xl">How can we <span className="text-gradient">help?</span></h1>
            <p className="mt-4 text-slate-400">Our support team is available 24/7 in Amharic and English.</p>
          </Reveal>
        </div>
      </section>

      <section className="py-8">
        <div className="container-x">
          <div className="grid gap-12 lg:grid-cols-2">
            {/* FAQ */}
            <Reveal>
              <h2 className="font-display text-2xl font-bold text-white">Frequently asked questions</h2>
              <div className="mt-6 space-y-3">
                {faqs.map((f, i) => {
                  const open = openIdx === i;
                  return (
                    <div key={i} className={`overflow-hidden rounded-xl border transition-colors ${open ? 'border-primary-400/30 bg-primary-400/5' : 'border-white/10 bg-white/[0.02]'}`}>
                      <button onClick={() => setOpenIdx(open ? null : i)} className="flex w-full items-center justify-between gap-3 px-4 py-3.5 text-left">
                        <span className="text-sm font-medium text-white">{f.q}</span>
                        <ChevronDown className={`h-4 w-4 shrink-0 text-slate-400 transition-transform duration-300 ${open ? 'rotate-180' : ''}`} />
                      </button>
                      <div className="grid transition-all duration-300 ease-out" style={{ gridTemplateRows: open ? '1fr' : '0fr' }}>
                        <div className="overflow-hidden"><p className="px-4 pb-4 text-sm text-slate-400">{f.a}</p></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Reveal>

            {/* Contact card */}
            <Reveal delay={120}>
              <div className="glass-strong h-full rounded-2xl p-7">
                <h3 className="font-display text-xl font-bold text-white">Get in touch</h3>
                <p className="mt-2 text-sm text-slate-400">Reach us through any of these channels.</p>

                <div className="mt-6 space-y-4">
                  <ContactRow icon={MessageCircle} label="Live Chat" value="Start a chat now" accent="#11bdf7" />
                  <ContactRow icon={Mail} label="Email" value="support@gamezone.et" accent="#34d399" />
                  <ContactRow icon={Phone} label="Phone / Telegram" value="+251 911 234 567" accent="#ff4516" />
                  <ContactRow icon={MapPin} label="Office" value="Bole, Addis Ababa, Ethiopia" accent="#f5b200" />
                </div>

                <div className="mt-7 rounded-xl border border-white/10 bg-gradient-to-br from-primary-400/10 to-transparent p-5">
                  <p className="text-sm font-semibold text-white">Average response time</p>
                  <p className="mt-1 font-mono text-2xl font-bold text-primary-300">&lt; 5 minutes</p>
                  <p className="mt-1 text-xs text-slate-500">For all live chat requests</p>
                </div>

                <div className="mt-5 flex items-center gap-2 rounded-xl border border-success-400/20 bg-success-400/5 px-4 py-3 text-xs text-slate-400">
                  <ShieldCheck className="h-4 w-4 text-success-400" /> Authorized reseller. We deliver through official channels.
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>
    </div>
  );
}

function ContactRow({ icon: Icon, label, value, accent }: { icon: typeof Mail; label: string; value: string; accent: string }) {
  return (
    <div className="flex items-center gap-4 rounded-xl border border-white/10 bg-white/[0.02] p-4 transition-colors hover:border-white/20">
      <span className="grid h-11 w-11 place-items-center rounded-xl" style={{ background: `${accent}22`, color: accent }}><Icon className="h-5 w-5" /></span>
      <div><p className="text-xs text-slate-500">{label}</p><p className="text-sm font-semibold text-white">{value}</p></div>
    </div>
  );
}
