import { useState, useEffect, useMemo } from 'react';
import {
  Trophy, Calendar, Users, MapPin, Gamepad2, Flame, Crosshair,
  X, Check, Clock, ShieldCheck, Zap, Timer,
} from 'lucide-react';
import { tournaments, games, formatETB } from '@/data/catalog';
import type { Tournament, Game } from '@/data/catalog';
import Reveal from '@/components/Reveal';
import { useTilt } from '@/hooks/useMotion';

const gameIcons: Record<string, typeof Flame> = { flame: Flame, crosshair: Crosshair, football: Crosshair };

const statusStyles: Record<Tournament['status'], { label: string; cls: string; dot: string }> = {
  open: { label: 'Open', cls: 'border-success-400/40 bg-success-400/10 text-success-400', dot: 'bg-success-400' },
  filling: { label: 'Filling fast', cls: 'border-gold-400/40 bg-gold-400/10 text-gold-300', dot: 'bg-gold-400' },
  full: { label: 'Full', cls: 'border-error-400/40 bg-error-400/10 text-error-400', dot: 'bg-error-400' },
  live: { label: 'Live now', cls: 'border-accent-500/50 bg-accent-500/15 text-accent-300', dot: 'bg-accent-500' },
  completed: { label: 'Completed', cls: 'border-white/20 bg-white/5 text-slate-400', dot: 'bg-slate-500' },
};

export default function TournamentsPage({
  onRegister,
}: {
  onRegister: (title: string, fee: number) => void;
}) {
  const [selected, setSelected] = useState<Tournament | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const totalPrize = tournaments.reduce((sum, t) => sum + t.prizePoolETB, 0);
  const openCount = tournaments.filter((t) => t.status === 'open' || t.status === 'filling').length;

  const statusFilters = [
    { id: 'all', label: 'All' },
    { id: 'open', label: 'Open' },
    { id: 'filling', label: 'Filling Fast' },
    { id: 'live', label: 'Live Now' },
    { id: 'completed', label: 'Completed' },
  ];

  const nextTournament = useMemo(() => {
    const upcoming = tournaments
      .filter((t) => t.status === 'open' || t.status === 'filling')
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return upcoming[0] ?? null;
  }, []);

  return (
    <div className="relative min-h-screen pt-20">
      {/* Header */}
      <section className="relative overflow-hidden py-12">
        <div className="absolute inset-0 -z-10 bg-radial-fade" />
        <div className="container-x">
          <Reveal className="text-center">
            <span className="chip border-gold-400/30 bg-gold-400/10 text-gold-200">
              <Trophy className="h-3.5 w-3.5" /> Esports Arena
            </span>
            <h1 className="mt-4 font-display text-4xl font-bold text-white sm:text-5xl">
              Live <span className="text-gradient-gold">tournaments</span>
            </h1>
            <p className="mt-4 text-slate-400">Register, compete, and win prize pools in Ethiopian Birr.</p>
          </Reveal>

          {/* Stats */}
          <Reveal delay={100} className="mt-8">
            <div className="grid grid-cols-3 gap-4">
              <div className="glass rounded-2xl p-5 text-center">
                <Trophy className="mx-auto h-6 w-6 text-gold-400" />
                <p className="mt-2 font-mono text-xl font-bold text-white">{formatETB(totalPrize)}</p>
                <p className="text-xs text-slate-400">Total prize pool</p>
              </div>
              <div className="glass rounded-2xl p-5 text-center">
                <Zap className="mx-auto h-6 w-6 text-primary-400" />
                <p className="mt-2 font-mono text-xl font-bold text-white">{openCount}</p>
                <p className="text-xs text-slate-400">Open events</p>
              </div>
              <div className="glass rounded-2xl p-5 text-center">
                <Users className="mx-auto h-6 w-6 text-accent-400" />
                <p className="mt-2 font-mono text-xl font-bold text-white">{tournaments.reduce((s, t) => s + t.slotsTotal, 0)}</p>
                <p className="text-xs text-slate-400">Total slots</p>
              </div>
            </div>
          </Reveal>

          {/* Next event countdown */}
          {nextTournament && (
            <Reveal delay={150} className="mt-4">
              <CountdownBanner tournament={nextTournament} />
            </Reveal>
          )}

          {/* Status filter */}
          <Reveal delay={200} className="mt-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-500">Filter:</span>
              {statusFilters.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setStatusFilter(f.id)}
                  className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition-all ${
                    statusFilter === f.id
                      ? 'border-primary-400/50 bg-primary-400/15 text-primary-300'
                      : 'border-white/10 bg-white/5 text-slate-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* Three game-category sections */}
      {games.map((game, gi) => {
        let gameTournaments = tournaments.filter((t) => t.gameId === game.id);
        if (statusFilter !== 'all') {
          gameTournaments = gameTournaments.filter((t) => t.status === statusFilter);
        }
        if (gameTournaments.length === 0) return null;
        return (
          <GameTournamentSection
            key={game.id}
            game={game}
            tournaments={gameTournaments}
            sectionIndex={gi}
            onRegisterClick={(t) => {
              if (t.status !== 'full' && t.status !== 'completed') setSelected(t);
            }}
          />
        );
      })}

      <RegisterModal
        tournament={selected}
        onClose={() => setSelected(null)}
        onConfirm={() => { if (selected) onRegister(selected.title, selected.entryFeeETB); setSelected(null); }}
      />
    </div>
  );
}

function GameTournamentSection({
  game,
  tournaments: gameTournaments,
  sectionIndex,
  onRegisterClick,
}: {
  game: Game;
  tournaments: Tournament[];
  sectionIndex: number;
  onRegisterClick: (t: Tournament) => void;
}) {
  const Icon = gameIcons[game.iconKey] ?? Gamepad2;
  const sectionPrize = gameTournaments.reduce((s, t) => s + t.prizePoolETB, 0);
  const sectionOpen = gameTournaments.filter((t) => t.status === 'open' || t.status === 'filling').length;

  return (
    <section className="py-8" id={`tournaments-${game.id}`}>
      <div className="container-x">
        {/* Section header */}
        <Reveal>
          <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-4">
              <span
                className="grid h-14 w-14 place-items-center rounded-2xl border"
                style={{
                  borderColor: `${game.accent}55`,
                  background: `${game.accent}15`,
                  color: game.accent,
                }}
              >
                <Icon className="h-7 w-7" />
              </span>
              <div>
                <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
                  {game.name} <span className="text-slate-500">Tournaments</span>
                </h2>
                <p className="mt-0.5 text-sm text-slate-400">{game.tagline}</p>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right">
                <p className="font-mono text-lg font-bold text-gold-300">{formatETB(sectionPrize)}</p>
                <p className="text-xs text-slate-500">Prize pool</p>
              </div>
              <div className="h-10 w-px bg-white/10" />
              <div className="text-right">
                <p className="font-mono text-lg font-bold text-white">{sectionOpen}</p>
                <p className="text-xs text-slate-500">Open events</p>
              </div>
            </div>
          </div>
          <div
            className="mb-6 h-px w-full"
            style={{ background: `linear-gradient(90deg, ${game.accent}66, transparent)` }}
          />
        </Reveal>

        {/* Cards */}
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {gameTournaments.map((t, i) => (
            <Reveal key={t.id} delay={sectionIndex * 80 + i * 60} as="article">
              <TournamentCard
                tournament={t}
                onRegister={() => onRegisterClick(t)}
              />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

function TournamentCard({ tournament, onRegister }: { tournament: Tournament; onRegister: () => void }) {
  const { ref, onMove, onLeave } = useTilt<HTMLDivElement>(7);
  const game = games.find((g) => g.id === tournament.gameId);
  const Icon = game ? gameIcons[game.iconKey] : Gamepad2;
  const status = statusStyles[tournament.status];
  const pct = Math.round((tournament.slotsFilled / tournament.slotsTotal) * 100);
  const date = new Date(tournament.date);
  const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const timeStr = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const full = tournament.status === 'full' || tournament.status === 'completed';

  return (
    <div ref={ref} onPointerMove={onMove} onPointerLeave={onLeave} className="preserve-3d group h-full overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] transition-all duration-200 hover:border-white/20">
      <div className="relative h-24 overflow-hidden" style={{ background: `linear-gradient(120deg, ${game?.accent}33, transparent)` }}>
        <div className="absolute inset-0 bg-grid opacity-30" />
        <div className="absolute inset-0 flex items-center justify-between px-5">
          <span className="grid h-12 w-12 place-items-center rounded-xl" style={{ background: `${game?.accent}33`, color: game?.accent }}>
            <Icon className="h-6 w-6" />
          </span>
          <span className={`flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${status.cls}`}>
            <span className={`h-1.5 w-1.5 rounded-full ${status.dot} ${tournament.status === 'live' ? 'animate-pulse' : ''}`} />
            {status.label}
          </span>
        </div>
      </div>
      <div className="p-5" style={{ transform: 'translateZ(20px)' }}>
        <p className="text-xs text-slate-500">{tournament.gameName} · {tournament.mode}</p>
        <h3 className="mt-1 font-display text-lg font-bold text-white">{tournament.title}</h3>
        <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-xs text-slate-400">
          <span className="flex items-center gap-1.5"><Calendar className="h-3.5 w-3.5 text-primary-400" /> {dateStr} · {timeStr}</span>
          <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5 text-primary-400" /> {tournament.region.split('·')[0]}</span>
          <span className="flex items-center gap-1.5"><Users className="h-3.5 w-3.5 text-primary-400" /> {tournament.slotsTotal} slots</span>
          <span className="flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5 text-primary-400" /> {tournament.format}</span>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <div><p className="text-xs text-slate-500">Prize pool</p><p className="font-mono text-lg font-bold text-gold-300">{formatETB(tournament.prizePoolETB)}</p></div>
          <div className="text-right"><p className="text-xs text-slate-500">Entry</p><p className="font-mono text-sm font-semibold text-slate-200">{formatETB(tournament.entryFeeETB)}</p></div>
        </div>
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-slate-400"><span>{tournament.slotsFilled} registered</span><span>{pct}%</span></div>
          <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-gradient-to-r from-primary-400 to-accent-400 transition-all duration-1000" style={{ width: `${pct}%` }} />
          </div>
        </div>
        <button onClick={onRegister} disabled={full} className={`mt-5 w-full rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${full ? 'cursor-not-allowed border border-white/10 bg-white/5 text-slate-500' : 'bg-primary-400 text-ink-950 hover:bg-primary-300 hover:shadow-glow'}`}>
          {full ? 'Slots Full' : 'Register Now'}
        </button>
      </div>
    </div>
  );
}

function RegisterModal({ tournament, onClose, onConfirm }: { tournament: Tournament | null; onClose: () => void; onConfirm: () => void }) {
  const [team, setTeam] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  if (!tournament) return null;
  const game = games.find((g) => g.id === tournament.gameId);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-ink-950/80 backdrop-blur-sm animate-fade-up" onClick={onClose} style={{ animationDuration: '0.3s' }} />
      <div className="glass-strong relative z-10 w-full max-w-md animate-scale-in overflow-hidden rounded-2xl">
        <div className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, ${game?.accent}, transparent)` }} />
        <div className="flex items-center justify-between border-b border-white/10 p-5">
          <div className="flex items-center gap-2"><Trophy className="h-5 w-5 text-gold-400" /><h3 className="font-display text-lg font-bold text-white">Register for tournament</h3></div>
          <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 text-slate-400 hover:text-white"><X className="h-5 w-5" /></button>
        </div>
        {!confirmed ? (
          <div className="p-5 animate-fade-up" style={{ animationDuration: '0.3s' }}>
            <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
              <p className="font-display text-base font-bold text-white">{tournament.title}</p>
              <p className="text-xs text-slate-400">{tournament.gameName} · {tournament.mode}</p>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg bg-white/5 p-2"><p className="text-slate-500">Prize pool</p><p className="font-mono font-bold text-gold-300">{formatETB(tournament.prizePoolETB)}</p></div>
                <div className="rounded-lg bg-white/5 p-2"><p className="text-slate-500">Entry fee</p><p className="font-mono font-bold text-primary-300">{formatETB(tournament.entryFeeETB)}</p></div>
              </div>
            </div>
            <label className="mt-5 block text-sm font-medium text-slate-300">Team / Player name</label>
            <input value={team} onChange={(e) => setTeam(e.target.value)} placeholder="Enter your team or in-game name" className="mt-2 w-full rounded-xl border border-white/10 bg-ink-900/60 px-4 py-3 text-white placeholder:text-slate-600 focus:border-primary-400/50 focus:outline-none focus:ring-2 focus:ring-primary-400/20" />
            <div className="mt-4 space-y-2 text-xs text-slate-400">
              <p className="flex items-center gap-2"><Clock className="h-3.5 w-3.5 text-primary-400" /> {new Date(tournament.date).toLocaleString('en-US', { dateStyle: 'long', timeStyle: 'short' })}</p>
              <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 text-primary-400" /> {tournament.region}</p>
              <p className="flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5 text-success-400" /> {tournament.format}</p>
            </div>
            <button disabled={team.trim().length < 2} onClick={() => setConfirmed(true)} className="btn-primary mt-6 w-full disabled:cursor-not-allowed disabled:opacity-40"><Zap className="h-4 w-4" /> Confirm Registration</button>
          </div>
        ) : (
          <div className="p-8 text-center animate-scale-in">
            <div className="grid h-16 w-16 place-items-center rounded-full bg-success-400/15 text-success-400 mx-auto"><Check className="h-8 w-8" /></div>
            <p className="mt-4 font-display text-lg font-bold text-white">You're registered!</p>
            <p className="mt-1 text-sm text-slate-400">{tournament.title} — we'll send match details to your account.</p>
            <button onClick={onConfirm} className="btn-primary mt-6 w-full">Pay entry & finish</button>
          </div>
        )}
      </div>
    </div>
  );
}

function CountdownBanner({ tournament }: { tournament: Tournament }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  const target = new Date(tournament.date).getTime();
  const diff = Math.max(0, target - now);
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  const secs = Math.floor((diff % 60000) / 1000);
  const game = games.find((g) => g.id === tournament.gameId);

  const units = [
    { label: 'Days', value: days },
    { label: 'Hours', value: hours },
    { label: 'Mins', value: mins },
    { label: 'Secs', value: secs },
  ];

  return (
    <div className="glass-strong relative overflow-hidden rounded-2xl p-5">
      <div className="absolute -right-8 -top-8 h-28 w-28 rounded-full bg-gold-400/15 blur-3xl" />
      <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-xl bg-gold-400/15 text-gold-300">
            <Timer className="h-6 w-6" />
          </span>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-gold-300">Next event starts in</p>
            <p className="font-display text-lg font-bold text-white">{tournament.title}</p>
            <p className="text-xs text-slate-400">{tournament.gameName} · {formatETB(tournament.prizePoolETB)} prize pool</p>
          </div>
        </div>
        <div className="flex gap-2">
          {units.map((u) => (
            <div key={u.label} className="min-w-[3.5rem] rounded-xl border border-white/10 bg-ink-900/60 px-3 py-2 text-center">
              <p className="font-mono text-2xl font-bold text-white tabular-nums">{u.value.toString().padStart(2, '0')}</p>
              <p className="text-[0.625rem] uppercase tracking-wider text-slate-500">{u.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
