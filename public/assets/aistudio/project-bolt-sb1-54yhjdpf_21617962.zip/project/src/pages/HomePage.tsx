import { Flame, Crosshair, Trophy, Zap, ChevronRight, Sparkles, Star, ArrowRight, Users, TrendingUp, ShieldCheck } from 'lucide-react';
import ParticleField from '@/components/ParticleField';
import FloatingShapes from '@/components/FloatingShapes';
import Character3D from '@/components/Character3D';
import Reveal from '@/components/Reveal';
import { useParallax, useCountUp, useReveal, useTilt } from '@/hooks/useMotion';
import { HERO_IMAGE, formatETB, games, tournaments } from '@/data/catalog';
import type { PageId } from '@/hooks/useRouter';

const stats = [
  { label: 'Active gamers', value: 128000, suffix: '+', icon: Zap },
  { label: 'Tournaments hosted', value: 340, suffix: '', icon: Trophy },
  { label: 'Top-ups delivered', value: 92000, suffix: '+', icon: Sparkles },
  { label: 'Prize pool (Br)', value: 1850000, suffix: '', icon: Star, money: true },
];

const gameIcons: Record<string, typeof Flame> = {
  flame: Flame,
  crosshair: Crosshair,
  football: Crosshair,
};

export default function HomePage({ onNavigate }: { onNavigate: (p: PageId) => void }) {
  const { ref: bgRef, offset } = useParallax(0.18);
  const { ref: statsRef, inView } = useReveal<HTMLDivElement>();

  return (
    <div className="relative min-h-screen overflow-hidden pt-16">
      {/* === HERO === */}
      <section id="home-hero" className="relative overflow-hidden">
        <div ref={bgRef as any} className="absolute inset-0 -z-10">
          <img
            src={HERO_IMAGE}
            alt=""
            className="h-[120%] w-full object-cover opacity-30"
            style={{ transform: `translateY(${offset}px)` }}
          />
          <div className="absolute inset-0 bg-gradient-to-b from-ink-950/70 via-ink-950/85 to-ink-950" />
          <div className="absolute inset-0 bg-grid opacity-40" />
        </div>

        <ParticleField />
        <FloatingShapes />

        <div className="container-x relative flex min-h-[calc(100vh-4rem)] flex-col justify-center py-16">
          <div className="grid items-center gap-12 lg:grid-cols-12">
            {/* Left: copy */}
            <div className="lg:col-span-6">
              <div className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-primary-400/30 bg-primary-400/10 px-4 py-1.5 text-sm text-primary-200">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-success-400" />
                </span>
                Ethiopia's #1 game top-up & esports platform
              </div>

              <h1
                className="animate-fade-up mt-6 font-display text-4xl font-bold leading-[1.05] text-white text-shadow-glow sm:text-5xl lg:text-6xl"
                style={{ animationDelay: '0.1s' }}
              >
                Top up. Compete.
                <br />
                <span className="text-gradient">Dominate the lobby.</span>
              </h1>

              <p
                className="animate-fade-up mt-6 max-w-xl text-lg text-slate-400"
                style={{ animationDelay: '0.2s' }}
              >
                Buy diamonds, UC and FC Points in <span className="text-slate-200">Ethiopian Birr</span>,
                unlock memberships, and join live tournaments for Free Fire, PUBG Mobile, and EA Sports FC.
              </p>

              <div className="animate-fade-up mt-8 flex flex-wrap items-center gap-3" style={{ animationDelay: '0.3s' }}>
                <button onClick={() => onNavigate('topup')} className="btn-primary text-base">
                  <Zap className="h-5 w-5" /> Top Up Now
                </button>
                <button onClick={() => onNavigate('tournaments')} className="btn-ghost text-base">
                  <Trophy className="h-5 w-5 text-gold-400" /> Browse Tournaments
                </button>
              </div>

              {/* game pills */}
              <div className="animate-fade-up mt-10 flex flex-wrap gap-2.5" style={{ animationDelay: '0.4s' }}>
                {games.map((g) => {
                  const Icon = gameIcons[g.iconKey];
                  return (
                    <button
                      key={g.id}
                      onClick={() => onNavigate('topup')}
                      className="chip group transition-colors hover:border-primary-300/50 hover:bg-primary-400/10 hover:text-white"
                    >
                      {g.iconKey === 'flame' && <Flame className="h-3.5 w-3.5 text-accent-400" />}
                      {g.iconKey === 'crosshair' && <Crosshair className="h-3.5 w-3.5 text-primary-400" />}
                      {g.iconKey === 'football' && <span className="text-success-400">⚽</span>}
                      {g.name}
                      <ChevronRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right: 3D character scene */}
            <div className="lg:col-span-6">
              <div className="animate-scale-in perspective" style={{ animationDelay: '0.35s' }}>
                <div className="glass-strong relative h-[420px] overflow-hidden rounded-3xl">
                  <div className="absolute inset-0 bg-grid opacity-20" />
                  <div className="absolute left-4 top-4 z-10">
                    <span className="chip border-primary-400/30 bg-primary-400/10 text-primary-200">
                      <span className="relative flex h-2 w-2">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success-400 opacity-75" />
                        <span className="relative inline-flex h-2 w-2 rounded-full bg-success-400" />
                      </span>
                      3D Arrival Animation
                    </span>
                  </div>
                  <Character3D accent="#11bdf7" />
                  <div className="absolute bottom-4 right-4 z-10 text-right">
                    <p className="font-display text-sm font-bold text-white">Tactical Operator</p>
                    <p className="text-xs text-slate-400">Live 3D arrival sequence</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div ref={statsRef} className="mt-16 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {stats.map((s, i) => (
              <StatCard key={s.label} stat={s} active={inView} delay={i * 0.1} />
            ))}
          </div>
        </div>
      </section>

      {/* === FEATURED GAMES === */}
      <section className="relative py-24">
        <div className="container-x">
          <Reveal className="mx-auto max-w-2xl text-center">
            <span className="chip border-primary-400/30 bg-primary-400/10 text-primary-200">
              <Gamepad2Icon /> Our Games
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl lg:text-5xl">
              Three games. <span className="text-gradient">One platform.</span>
            </h2>
            <p className="mt-4 text-slate-400">
              We support the most popular competitive games in Ethiopia. Top up, unlock passes, and compete.
            </p>
          </Reveal>

          <div className="mt-10 grid gap-6 md:grid-cols-3">
            {games.map((g, i) => (
              <Reveal key={g.id} delay={i * 120} as="article">
                <GameCard game={g} onTopUp={() => onNavigate('topup')} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* === UPCOMING TOURNAMENTS PREVIEW === */}
      <section className="relative py-24">
        <div className="absolute inset-0 -z-10 bg-radial-fade" />
        <div className="container-x">
          <Reveal className="flex items-end justify-between gap-4">
            <div>
              <span className="chip border-gold-400/30 bg-gold-400/10 text-gold-200">
                <Trophy className="h-3.5 w-3.5" /> Tournaments
              </span>
              <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">
                Upcoming <span className="text-gradient-gold">events</span>
              </h2>
            </div>
            <button onClick={() => onNavigate('tournaments')} className="btn-ghost shrink-0 text-sm">
              View all <ArrowRight className="h-4 w-4" />
            </button>
          </Reveal>

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {tournaments.slice(0, 3).map((t, i) => (
              <Reveal key={t.id} delay={i * 80}>
                <MiniTournamentCard tournament={t} onRegister={() => onNavigate('tournaments')} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* === HOW IT WORKS === */}
      <section className="relative py-24">
        <div className="container-x">
          <Reveal className="mx-auto max-w-2xl text-center">
            <h2 className="font-display text-3xl font-bold text-white sm:text-4xl">
              How it <span className="text-gradient">works</span>
            </h2>
          </Reveal>

          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              { step: '01', title: 'Choose your game', desc: 'Select Free Fire, PUBG Mobile, or EA Sports FC', icon: Gamepad2Icon },
              { step: '02', title: 'Top up or register', desc: 'Buy diamonds, UC, FC Points, or join a tournament', icon: Zap },
              { step: '03', title: 'Play instantly', desc: 'Delivery to your in-game ID in minutes', icon: Trophy },
            ].map((s, i) => {
              const Icon = s.icon;
              return (
                <Reveal key={s.step} delay={i * 120}>
                  <div className="relative text-center">
                    <div className="relative mx-auto grid h-20 w-20 place-items-center rounded-2xl glass">
                      <Icon className="h-8 w-8 text-primary-400" />
                      <span className="absolute -top-2 -right-2 grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-primary-400 to-accent-500 font-mono text-xs font-bold text-ink-950">
                        {s.step}
                      </span>
                    </div>
                    <h3 className="mt-5 font-display text-xl font-bold text-white">{s.title}</h3>
                    <p className="mt-2 text-sm text-slate-400">{s.desc}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* === WHY CHOOSE US === */}
      <section className="relative py-24">
        <div className="container-x">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: ShieldCheck, title: 'Secure payments', desc: 'Telebirr, CBE, Chapa — all encrypted' },
              { icon: Zap, title: 'Instant delivery', desc: 'Top-ups arrive in 1\u20135 minutes' },
              { icon: Users, title: 'Active community', desc: '128K+ Ethiopian gamers' },
              { icon: TrendingUp, title: 'Best prices', desc: 'Competitive ETB pricing' },
            ].map((f, i) => {
              const Icon = f.icon;
              return (
                <Reveal key={f.title} delay={i * 80}>
                  <div className="glass rounded-2xl p-5">
                    <Icon className="h-6 w-6 text-primary-400" />
                    <h3 className="mt-3 font-display text-base font-bold text-white">{f.title}</h3>
                    <p className="mt-1 text-sm text-slate-400">{f.desc}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}

// Inline icon to avoid extra import clutter
function Gamepad2Icon() {
  return <Zap className="h-3.5 w-3.5" />;
}

function StatCard({ stat, active, delay }: { stat: typeof stats[number]; active: boolean; delay: number }) {
  const v = useCountUp(stat.value, active);
  const Icon = stat.icon;
  return (
    <div
      className={`glass animate-fade-up rounded-2xl p-5 ${active ? 'animate-count-pop' : 'opacity-0'}`}
      style={{ animationDelay: `${delay}s` }}
    >
      <Icon className="h-5 w-5 text-primary-400" />
      <p className="mt-3 font-mono text-2xl font-bold text-white sm:text-3xl">
        {stat.money ? formatETB(v).replace('Br ', '') : v.toLocaleString()}
        {stat.suffix}
      </p>
      <p className="mt-1 text-xs text-slate-400 sm:text-sm">{stat.label}</p>
    </div>
  );
}

function GameCard({ game, onTopUp }: { game: typeof games[number]; onTopUp: () => void }) {
  const { ref, onMove, onLeave } = useTilt<HTMLDivElement>(8);
  const Icon = gameIcons[game.iconKey];

  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      className="preserve-3d group relative h-full overflow-hidden rounded-2xl border border-white/10 transition-all duration-200 hover:border-white/20"
    >
      <div className="relative h-40 overflow-hidden">
        <img src={game.coverImage} alt="" className="h-full w-full object-cover opacity-40 transition-transform duration-500 group-hover:scale-110" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-900 to-transparent" />
        <div className="absolute left-4 top-4 flex items-center gap-3">
          <span
            className="grid h-12 w-12 place-items-center rounded-xl font-display text-lg font-bold text-white"
            style={{ background: `linear-gradient(135deg, ${game.accent}, #0a0c1b)`, boxShadow: `0 0 20px -4px ${game.accent}80` }}
          >
            {game.logoInitials}
          </span>
        </div>
        <div className="absolute bottom-3 left-4 right-4">
          <h3 className="font-display text-xl font-bold text-white">{game.name}</h3>
          <p className="text-xs text-slate-300">{game.tagline}</p>
        </div>
      </div>

      <div className="p-5" style={{ transform: 'translateZ(20px)' }}>
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span className="flex items-center gap-1"><Star className="h-3 w-3 text-gold-400" /> {game.rating}</span>
          <span>·</span>
          <span>{game.activePlayers}</span>
          <span>·</span>
          <span>{game.platform}</span>
        </div>
        <p className="mt-3 text-sm text-slate-400 line-clamp-2">{game.description}</p>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {game.whatYouCanBuy.slice(0, 3).map((item) => (
            <span key={item} className="rounded-md bg-white/5 px-2 py-1 text-xs text-slate-400">{item}</span>
          ))}
        </div>
        <button
          onClick={onTopUp}
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-ink-950 transition-all hover:scale-[1.02]"
          style={{ background: game.accent }}
        >
          <Icon className="h-4 w-4" /> Top Up {game.name}
        </button>
      </div>
    </div>
  );
}

function MiniTournamentCard({ tournament, onRegister }: { tournament: typeof tournaments[number]; onRegister: () => void }) {
  const game = games.find((g) => g.id === tournament.gameId);
  const pct = Math.round((tournament.slotsFilled / tournament.slotsTotal) * 100);
  const date = new Date(tournament.date);
  const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs text-slate-500">{tournament.gameName}</span>
        <span className="chip border-gold-400/30 bg-gold-400/10 text-gold-200">
          <Trophy className="h-3 w-3" /> {formatETB(tournament.prizePoolETB)}
        </span>
      </div>
      <h3 className="mt-2 font-display text-lg font-bold text-white">{tournament.title}</h3>
      <div className="mt-2 flex items-center gap-3 text-xs text-slate-400">
        <span>{dateStr}</span>
        <span>·</span>
        <span>{tournament.mode}</span>
      </div>
      <div className="mt-4">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>{tournament.slotsFilled}/{tournament.slotsTotal}</span>
          <span>{pct}%</span>
        </div>
        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full transition-all duration-1000"
            style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${game?.accent}, transparent)` }}
          />
        </div>
      </div>
      <button onClick={onRegister} className="btn-ghost mt-4 w-full text-sm">View details <ArrowRight className="h-3.5 w-3.5" /></button>
    </div>
  );
}
