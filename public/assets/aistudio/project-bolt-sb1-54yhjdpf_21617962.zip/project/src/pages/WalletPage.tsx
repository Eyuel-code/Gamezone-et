import { useState } from 'react';
import { Wallet, Plus, ArrowDownLeft, ArrowUpRight, Coins, History, ShieldCheck, Smartphone, Building2, Filter } from 'lucide-react';
import Reveal from '@/components/Reveal';
import { formatETB } from '@/data/catalog';

const transactions = [
  { type: 'topup', label: '520 Diamonds — Free Fire', amount: -650, time: '2 hrs ago' },
  { type: 'reward', label: 'Loyalty points redeemed', amount: 50, time: '1 day ago' },
  { type: 'deposit', label: 'Telebirr deposit', amount: 1000, time: '2 days ago' },
  { type: 'tournament', label: 'Highland Cup entry', amount: -250, time: '3 days ago' },
  { type: 'cashback', label: 'Gold tier 5% cashback', amount: 32, time: '4 days ago' },
  { type: 'topup', label: '660 UC — PUBG Mobile', amount: -1300, time: '5 days ago' },
];

const paymentMethods = [
  { name: 'Telebirr', icon: Smartphone, desc: 'Instant deposit via USSD or app' },
  { name: 'CBE Birr', icon: Building2, desc: 'Commercial Bank of Ethiopia' },
  { name: 'Chapa', icon: Wallet, desc: 'Cards & mobile money gateway' },
];

export default function WalletPage({
  balance,
  onDeposit,
}: {
  balance: number;
  onDeposit: (amount: number) => void;
}) {
  const [txFilter, setTxFilter] = useState<string>('all');
  const [customAmount, setCustomAmount] = useState('');

  const filteredTx = transactions.filter((t) => txFilter === 'all' || t.type === txFilter);

  const txTypes = [
    { id: 'all', label: 'All' },
    { id: 'topup', label: 'Top-ups' },
    { id: 'deposit', label: 'Deposits' },
    { id: 'reward', label: 'Rewards' },
    { id: 'tournament', label: 'Tournaments' },
    { id: 'cashback', label: 'Cashback' },
  ];

  const handleCustomDeposit = () => {
    const amt = parseInt(customAmount, 10);
    if (amt > 0) {
      onDeposit(amt);
      setCustomAmount('');
    }
  };

  return (
    <div className="relative min-h-screen pt-20">
      <section className="relative overflow-hidden py-12">
        <div className="absolute inset-0 -z-10 bg-radial-fade" />
        <div className="container-x">
          <Reveal className="text-center">
            <span className="chip border-primary-400/30 bg-primary-400/10 text-primary-200"><Wallet className="h-3.5 w-3.5" /> Wallet</span>
            <h1 className="mt-4 font-display text-4xl font-bold text-white sm:text-5xl">Your <span className="text-gradient">GameZone wallet</span></h1>
            <p className="mt-4 text-slate-400">Deposit once, then top up and register in one tap.</p>
          </Reveal>
        </div>
      </section>

      <section className="py-6">
        <div className="container-x space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Balance card */}
            <Reveal className="lg:col-span-1">
              <div className="glass-strong relative overflow-hidden rounded-2xl p-6">
                <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-primary-400/20 blur-3xl" />
                <p className="text-sm text-slate-400">Available balance</p>
                <p className="mt-2 font-mono text-4xl font-bold text-white">{formatETB(balance)}</p>
                <div className="mt-5 flex flex-wrap gap-3">
                  {[500, 1000, 2000].map((amt) => (
                    <button key={amt} onClick={() => onDeposit(amt)} className="rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm font-medium text-slate-200 transition-all hover:border-primary-300/50 hover:bg-white/10">
                      +{formatETB(amt).replace('Br ', '')}
                    </button>
                  ))}
                </div>
                <div className="mt-3 flex gap-2">
                  <input
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="Custom amount"
                    className="w-full rounded-lg border border-white/10 bg-ink-900/60 px-3 py-2 text-sm text-white placeholder:text-slate-600 focus:border-primary-400/50 focus:outline-none"
                  />
                  <button onClick={handleCustomDeposit} disabled={!customAmount || parseInt(customAmount) <= 0} className="shrink-0 rounded-lg bg-primary-400 px-4 py-2 text-sm font-semibold text-ink-950 transition-all hover:bg-primary-300 disabled:cursor-not-allowed disabled:opacity-40">
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <button onClick={() => onDeposit(1000)} className="btn-primary mt-4 w-full"><Plus className="h-4 w-4" /> Deposit</button>
                <div className="mt-6 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.02] p-3 text-xs text-slate-400"><Coins className="h-4 w-4 text-gold-400" />Earn loyalty points on every wallet transaction.</div>
              </div>
            </Reveal>

            {/* Transactions */}
            <Reveal delay={120} className="lg:col-span-2">
              <div className="glass-strong rounded-2xl p-6">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-2"><History className="h-5 w-5 text-slate-400" /><h2 className="font-display text-lg font-bold text-white">Recent transactions</h2></div>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Filter className="h-3.5 w-3.5 text-slate-500" />
                    {txTypes.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setTxFilter(t.id)}
                        className={`rounded-full border px-2.5 py-1 text-xs font-medium transition-all ${
                          txFilter === t.id
                            ? 'border-primary-400/50 bg-primary-400/15 text-primary-300'
                            : 'border-white/10 bg-white/5 text-slate-400 hover:text-white'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="mt-4 divide-y divide-white/5">
                  {filteredTx.length === 0 ? (
                    <p className="py-8 text-center text-sm text-slate-500">No transactions in this category.</p>
                  ) : (
                    filteredTx.map((tx, i) => (
                      <div key={i} className="flex items-center gap-4 py-3">
                        <span className={`grid h-10 w-10 place-items-center rounded-xl ${tx.amount > 0 ? 'bg-success-400/10 text-success-400' : 'bg-error-400/10 text-error-400'}`}>
                          {tx.amount > 0 ? <ArrowDownLeft className="h-5 w-5" /> : <ArrowUpRight className="h-5 w-5" />}
                        </span>
                        <div className="min-w-0 flex-1"><p className="truncate text-sm font-medium text-white">{tx.label}</p><p className="text-xs text-slate-500">{tx.time}</p></div>
                        <span className={`font-mono text-sm font-bold ${tx.amount > 0 ? 'text-success-400' : 'text-slate-300'}`}>{tx.amount > 0 ? '+' : ''}{formatETB(Math.abs(tx.amount))}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </Reveal>
          </div>

          {/* Payment methods */}
          <Reveal>
            <div className="glass rounded-2xl p-6">
              <h2 className="font-display text-lg font-bold text-white">Supported payment methods</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                {paymentMethods.map((m) => {
                  const Icon = m.icon;
                  return (
                    <div key={m.name} className="flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.02] p-4">
                      <span className="grid h-11 w-11 place-items-center rounded-xl bg-primary-400/15 text-primary-300"><Icon className="h-5 w-5" /></span>
                      <div><p className="text-sm font-semibold text-white">{m.name}</p><p className="text-xs text-slate-400">{m.desc}</p></div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-5 flex items-center gap-2 rounded-xl border border-success-400/20 bg-success-400/5 px-4 py-3 text-xs text-slate-400">
                <ShieldCheck className="h-4 w-4 text-success-400" /> All deposits are encrypted and processed instantly. Your card details are never stored.
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
