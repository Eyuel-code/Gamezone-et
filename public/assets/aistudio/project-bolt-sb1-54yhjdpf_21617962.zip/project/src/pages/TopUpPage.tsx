import { useState } from 'react';
import {
  Flame, Crosshair, Gem, Coins, CircleDot, Crown, ArrowUp, Check, Sparkles,
  ShieldCheck, Zap, Gift, Star, Info,
} from 'lucide-react';
import { games, formatETB, rarityStyles } from '@/data/catalog';
import type { Game, TopUpPackage, MembershipTier, GamePass, CrateItem } from '@/data/catalog';
import Reveal from '@/components/Reveal';
import ItemShowcase3D from '@/components/ItemShowcase3D';
import PurchaseModal from '@/components/PurchaseModal';
import { useTilt } from '@/hooks/useMotion';

type Tab = 'topup' | 'membership' | 'passes' | 'crates';

const topUpIcons: Record<string, typeof Gem> = { gem: Gem, coins: Coins, ball: CircleDot };
const gameIcons: Record<string, typeof Flame> = { flame: Flame, crosshair: Crosshair, football: Crosshair };

export default function TopUpPage({
  onPurchase,
}: {
  onPurchase: (label: string, priceETB: number) => void;
}) {
  const [activeGameId, setActiveGameId] = useState(games[0].id);
  const [tab, setTab] = useState<Tab>('topup');
  const [selected, setSelected] = useState<{ title: string; priceETB: number } | null>(null);

  const activeGame = games.find((g) => g.id === activeGameId)!;

  const handleBuy = (title: string, priceETB: number) => setSelected({ title, priceETB });
  const confirm = () => {
    if (!selected) return;
    onPurchase(selected.title, selected.priceETB);
    setSelected(null);
  };

  return (
    <div className="relative min-h-screen pt-20">
      {/* Header */}
      <section className="relative overflow-hidden py-12">
        <div className="absolute inset-0 -z-10 bg-radial-fade" />
        <div className="container-x">
          <Reveal className="text-center">
            <span className="chip border-primary-400/30 bg-primary-400/10 text-primary-200">
              <Zap className="h-3.5 w-3.5" /> Instant Top-Up
            </span>
            <h1 className="mt-4 font-display text-4xl font-bold text-white sm:text-5xl">
              Top up your <span className="text-gradient">game</span>
            </h1>
            <p className="mt-4 text-slate-400">All prices in Ethiopian Birr. Instant delivery to your in-game ID.</p>
          </Reveal>
        </div>
      </section>

      {/* Game selector */}
      <section className="py-6">
        <div className="container-x">
          <div className="flex flex-wrap justify-center gap-3">
            {games.map((g) => {
              const Icon = gameIcons[g.iconKey];
              const active = g.id === activeGameId;
              return (
                <button
                  key={g.id}
                  onClick={() => { setTab('topup'); setActiveGameId(g.id); }}
                  className={`group relative flex items-center gap-3 rounded-2xl border px-5 py-3 transition-all duration-300 ${
                    active ? 'border-primary-400/60 bg-primary-400/10 shadow-glow' : 'border-white/10 bg-white/[0.03] hover:border-white/20 hover:bg-white/5'
                  }`}
                >
                  <span className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: `${g.accent}22`, color: g.accent }}>
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="text-left">
                    <span className={`block text-sm font-semibold ${active ? 'text-white' : 'text-slate-300'}`}>{g.name}</span>
                    <span className="block text-xs text-slate-500">{g.platform}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* Game showcase + details */}
      <GameShowcase game={activeGame} />

      {/* Tabs + content */}
      <section className="py-8">
        <div className="container-x">
          <GamePanel key={activeGame.id} game={activeGame} tab={tab} setTab={setTab} onBuy={handleBuy} />
        </div>
      </section>

      <PurchaseModal open={!!selected} item={selected} game={activeGame} onClose={() => setSelected(null)} onConfirm={confirm} />
    </div>
  );
}

function GameShowcase({ game }: { game: Game }) {
  const TopIcon = topUpIcons[game.topUpIcon];
  return (
    <Reveal className="py-6">
      <div className="container-x">
        <div className="glass-strong overflow-hidden rounded-3xl">
          <div className={`relative h-32 bg-gradient-to-r ${game.color} sm:h-36`}>
            <img src={game.coverImage} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-t from-ink-900 to-transparent" />
            <div className="relative flex h-full items-end gap-4 p-5 sm:p-7">
              <div
                className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl font-display text-2xl font-bold text-white shadow-card"
                style={{ background: `linear-gradient(135deg, ${game.accent}, #0a0c1b)` }}
              >
                {game.logoInitials}
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-xl font-bold text-white sm:text-2xl">{game.name}</h2>
                <p className="text-sm text-slate-300">{game.tagline}</p>
                <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><Star className="h-3 w-3 text-gold-400" /> {game.rating}</span>
                  <span>·</span><span>{game.activePlayers} active</span>
                  <span>·</span><span>{game.publisher}</span>
                </div>
              </div>
            </div>
          </div>

          {/* 3D showcase + what you can buy */}
          <div className="grid gap-6 p-6 lg:grid-cols-2 lg:p-8">
            <div className="glass relative min-h-[340px] overflow-hidden rounded-2xl">
              <div className="absolute left-4 top-4 z-10">
                <span className="chip" style={{ borderColor: `${game.accent}40`, color: game.accent }}>
                  <TopIcon className="h-3.5 w-3.5" /> {game.topUpLabel}
                </span>
              </div>
              <ItemShowcase3D game={game} />
            </div>
            <div>
              <h3 className="font-display text-lg font-bold text-white">About {game.name}</h3>
              <p className="mt-2 text-sm text-slate-400">{game.description}</p>
              <h4 className="mt-5 font-display text-sm font-bold uppercase tracking-wider text-slate-300">What you can buy</h4>
              <ul className="mt-3 grid gap-2 sm:grid-cols-2">
                {game.whatYouCanBuy.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-slate-300">
                    <Check className="mt-0.5 h-4 w-4 shrink-0" style={{ color: game.accent }} />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

function GamePanel({ game, tab, setTab, onBuy }: { game: Game; tab: Tab; setTab: (t: Tab) => void; onBuy: (t: string, p: number) => void }) {
  const TopIcon = topUpIcons[game.topUpIcon];

  const tabs = [
    { id: 'topup' as const, label: game.topUpLabel, icon: TopIcon },
    { id: 'membership' as const, label: 'Memberships', icon: Crown },
    { id: 'passes' as const, label: 'Passes', icon: ArrowUp },
    { id: 'crates' as const, label: 'Crates & Packs', icon: Gift },
  ];

  return (
    <Reveal delay={100}>
      <div className="glass-strong overflow-hidden rounded-3xl">
        {/* Tabs */}
        <div className="flex gap-1 overflow-x-auto border-b border-white/10 px-4 pt-3 scrollbar-none sm:px-7">
          {tabs.map((t) => {
            const Icon = t.icon;
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex shrink-0 items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${active ? 'text-white' : 'text-slate-400 hover:text-slate-200'}`}
              >
                <Icon className="h-4 w-4" style={active ? { color: game.accent } : {}} />
                {t.label}
                {active && <span className="absolute -bottom-px left-2 right-2 h-0.5 rounded-full" style={{ background: game.accent }} />}
              </button>
            );
          })}
        </div>

        <div className="p-4 sm:p-7">
          {tab === 'topup' && <PackageGrid game={game} onBuy={onBuy} />}
          {tab === 'membership' && <MembershipGrid game={game} onBuy={onBuy} />}
          {tab === 'passes' && <PassList game={game} onBuy={onBuy} />}
          {tab === 'crates' && <CrateGrid game={game} onBuy={onBuy} />}
        </div>
      </div>
    </Reveal>
  );
}

function PackageGrid({ game, onBuy }: { game: Game; onBuy: (t: string, p: number) => void }) {
  return (
    <div>
      <div className="mb-4 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.02] px-4 py-2.5 text-xs text-slate-400">
        <Info className="h-3.5 w-3.5 text-primary-400" />
        Enter your in-game Player ID at checkout. {game.topUpUnit} are delivered within minutes.
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {game.packages.map((pkg, i) => (
          <PackageCard key={pkg.id} pkg={pkg} game={game} index={i} onBuy={() => onBuy(`${pkg.amount} ${pkg.unit} — ${game.name}`, pkg.priceETB)} />
        ))}
      </div>
    </div>
  );
}

function PackageCard({ pkg, game, index, onBuy }: { pkg: TopUpPackage; game: Game; index: number; onBuy: () => void }) {
  const { ref, onMove, onLeave } = useTilt<HTMLDivElement>(8);
  const Icon = topUpIcons[game.topUpIcon];
  return (
    <div
      ref={ref} onPointerMove={onMove} onPointerLeave={onLeave}
      className="group preserve-3d relative animate-scale-in overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] p-5 transition-all duration-200 hover:border-white/20"
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {pkg.popular && <span className="absolute right-3 top-3 rounded-full bg-primary-400/20 px-2.5 py-0.5 text-xs font-semibold text-primary-200">Popular</span>}
      {pkg.bestValue && <span className="absolute right-3 top-3 rounded-full bg-gold-400/20 px-2.5 py-0.5 text-xs font-semibold text-gold-200">Best Value</span>}
      <div className="flex items-center gap-3" style={{ transform: 'translateZ(20px)' }}>
        <span className="grid h-12 w-12 place-items-center rounded-xl" style={{ background: `${game.accent}22`, color: game.accent }}>
          <Icon className="h-6 w-6" />
        </span>
        <div>
          <p className="font-display text-2xl font-bold text-white">{pkg.amount.toLocaleString()}</p>
          <p className="text-xs text-slate-400">{pkg.unit}</p>
        </div>
      </div>
      {pkg.bonus && (
        <p className="mt-3 inline-flex items-center gap-1 rounded-lg bg-success-400/10 px-2 py-1 text-xs font-medium text-success-400">
          <Sparkles className="h-3 w-3" /> +{pkg.bonus} bonus
        </p>
      )}
      <div className="mt-4 flex items-end justify-between" style={{ transform: 'translateZ(15px)' }}>
        <span className="font-mono text-lg font-bold text-white">{formatETB(pkg.priceETB)}</span>
        <button onClick={onBuy} className="rounded-lg px-3 py-2 text-sm font-semibold text-ink-950 transition-all hover:scale-105" style={{ background: game.accent }}>Buy</button>
      </div>
    </div>
  );
}

function MembershipGrid({ game, onBuy }: { game: Game; onBuy: (t: string, p: number) => void }) {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {game.memberships.map((m) => (
        <div
          key={m.id}
          className={`relative overflow-hidden rounded-2xl border p-6 transition-all duration-300 hover:shadow-card ${
            m.highlight ? 'border-gold-400/40 bg-gradient-to-br from-gold-400/10 to-transparent' : 'border-white/10 bg-white/[0.03] hover:border-white/20'
          }`}
        >
          {m.highlight && <span className="absolute right-4 top-4 rounded-full bg-gold-400/20 px-3 py-1 text-xs font-semibold text-gold-200">Recommended</span>}
          <Crown className={`h-7 w-7 ${m.highlight ? 'text-gold-400' : 'text-primary-400'}`} />
          <h4 className="mt-3 font-display text-xl font-bold text-white">{m.name}</h4>
          <p className="text-sm text-slate-400">{m.duration}</p>
          <p className="mt-4 font-mono text-3xl font-bold text-white">{formatETB(m.priceETB)}</p>
          <ul className="mt-5 space-y-2.5">
            {m.perks.map((perk) => (
              <li key={perk} className="flex items-start gap-2 text-sm text-slate-300">
                <Check className="mt-0.5 h-4 w-4 shrink-0" style={{ color: game.accent }} />{perk}
              </li>
            ))}
          </ul>
          <button onClick={() => onBuy(`${m.name} (${m.duration}) — ${game.name}`, m.priceETB)} className={`mt-6 w-full ${m.highlight ? 'btn-accent' : 'btn-ghost'}`}>
            Get {m.name.split(' ')[0]}
          </button>
        </div>
      ))}
    </div>
  );
}

function PassList({ game, onBuy }: { game: Game; onBuy: (t: string, p: number) => void }) {
  return (
    <div className="space-y-4">
      {game.passes.map((pass) => (
        <div
          key={pass.id}
          className={`group flex flex-col items-start gap-4 rounded-2xl border p-5 transition-all duration-300 hover:border-white/20 sm:flex-row sm:items-center sm:justify-between ${
            pass.highlight ? 'border-primary-400/30 bg-primary-400/5' : 'border-white/10 bg-white/[0.03]'
          }`}
        >
          <div className="flex items-center gap-4">
            <span className="grid h-12 w-12 place-items-center rounded-xl" style={{ background: `${game.accent}22`, color: game.accent }}>
              <ArrowUp className="h-6 w-6" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-display text-lg font-bold text-white">{pass.name}</h4>
                {pass.highlight && <span className="rounded-full bg-primary-400/20 px-2 py-0.5 text-xs text-primary-200">Featured</span>}
              </div>
              <p className="text-xs text-slate-400">{pass.season} · Max Level {pass.maxLevel}</p>
              <p className="mt-1 text-sm text-slate-300">{pass.reward}</p>
            </div>
          </div>
          <div className="flex items-center gap-4 sm:flex-col sm:items-end">
            <span className="font-mono text-xl font-bold text-white">{formatETB(pass.priceETB)}</span>
            <button onClick={() => onBuy(`${pass.name} (${pass.season}) — ${game.name}`, pass.priceETB)} className="rounded-lg px-4 py-2 text-sm font-semibold text-ink-950 transition-all hover:scale-105" style={{ background: game.accent }}>Unlock</button>
          </div>
        </div>
      ))}
      <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.02] px-4 py-3 text-xs text-slate-400">
        <ShieldCheck className="h-4 w-4 text-success-400" /> All passes are applied to your in-game account within minutes of payment.
      </div>
    </div>
  );
}

function CrateGrid({ game, onBuy }: { game: Game; onBuy: (t: string, p: number) => void }) {
  return (
    <div>
      <div className="mb-4 flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.02] px-4 py-2.5 text-xs text-slate-400">
        <Gift className="h-3.5 w-3.5 text-gold-400" /> Crates contain random rewards. Rarity determines drop chances.
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {game.crateItems.map((crate, i) => (
          <CrateCard key={crate.id} crate={crate} index={i} onBuy={() => onBuy(`${crate.name} — ${game.name}`, crate.priceETB)} />
        ))}
      </div>
    </div>
  );
}

function CrateCard({ crate, index, onBuy }: { crate: CrateItem; index: number; onBuy: () => void }) {
  const { ref, onMove, onLeave } = useTilt<HTMLDivElement>(8);
  const r = rarityStyles[crate.rarity];
  return (
    <div
      ref={ref} onPointerMove={onMove} onPointerLeave={onLeave}
      className={`preserve-3d relative animate-scale-in overflow-hidden rounded-2xl border p-5 ${r.border} ${r.bg} transition-all duration-200 hover:shadow-card`}
      style={{ animationDelay: `${index * 80}ms` }}
    >
      <div className="flex items-center justify-between" style={{ transform: 'translateZ(20px)' }}>
        <span className="grid h-12 w-12 place-items-center rounded-xl bg-white/5">
          <Gift className={`h-6 w-6 ${r.color}`} />
        </span>
        <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${r.color} ${r.bg} ${r.border} border`}>{r.label}</span>
      </div>
      <h4 className="mt-4 font-display text-sm font-bold text-white">{crate.name}</h4>
      <p className="text-xs text-slate-400">{crate.type}</p>
      <div className="mt-4 flex items-end justify-between" style={{ transform: 'translateZ(15px)' }}>
        <span className="font-mono text-lg font-bold text-white">{formatETB(crate.priceETB)}</span>
        <button onClick={onBuy} className="rounded-lg bg-white/10 px-3 py-2 text-sm font-semibold text-white transition-all hover:bg-white/20">Open</button>
      </div>
    </div>
  );
}
