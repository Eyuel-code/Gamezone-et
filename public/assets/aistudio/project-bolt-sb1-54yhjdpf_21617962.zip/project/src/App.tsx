import { useState, useCallback } from 'react';
import Navbar from '@/components/Navbar';
import ScrollProgress from '@/components/ScrollProgress';
import PageTransition from '@/components/PageTransition';
import Footer from '@/components/Footer';
import LiveActivityToast from '@/components/LiveActivityToast';
import ToastStack, { type Toast } from '@/components/ToastStack';
import PromoMarquee from '@/components/PromoMarquee';
import HomePage from '@/pages/HomePage';
import TopUpPage from '@/pages/TopUpPage';
import TournamentsPage from '@/pages/TournamentsPage';
import LeaderboardPage from '@/pages/LeaderboardPage';
import RewardsPage from '@/pages/RewardsPage';
import WalletPage from '@/pages/WalletPage';
import SupportPage from '@/pages/SupportPage';
import { useRouter } from '@/hooks/useRouter';
import { useEffect } from 'react';

export default function App() {
  const { page, navigate } = useRouter();
  const [walletBalance, setWalletBalance] = useState(1500);
  const [loyaltyPoints, setLoyaltyPoints] = useState(6800);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [page]);

  const pushToast = useCallback((message: string) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, message }]);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const handlePurchase = useCallback((label: string, priceETB: number) => {
    const earned = Math.floor(priceETB / 10);
    setLoyaltyPoints((p) => p + earned);
    pushToast(`Purchase confirmed — ${label}. Earned ${earned} loyalty points!`);
  }, [pushToast]);

  const handleRegister = useCallback((title: string, fee: number) => {
    const earned = Math.floor(fee / 5);
    setLoyaltyPoints((p) => p + earned);
    pushToast(`Registered for ${title}. Entry fee paid — earned ${earned} points!`);
  }, [pushToast]);

  const handleDeposit = useCallback((amount: number) => {
    setWalletBalance((b) => b + amount);
    const earned = Math.floor(amount / 20);
    setLoyaltyPoints((p) => p + earned);
    pushToast(`Deposited Br ${amount.toLocaleString()} to your wallet. Earned ${earned} points!`);
  }, [pushToast]);

  const handleRedeem = useCallback((name: string, cost: number) => {
    setLoyaltyPoints((p) => p - cost);
    pushToast(`Redeemed: ${name}! ${cost.toLocaleString()} points spent.`);
  }, [pushToast]);

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <ScrollProgress />
      <Navbar currentPage={page} onNavigate={navigate} walletBalance={walletBalance} loyaltyPoints={loyaltyPoints} />

      <main>
        <PageTransition pageKey={page}>
          {page === 'home' && <HomePage onNavigate={navigate} />}
          {page === 'topup' && <TopUpPage onPurchase={handlePurchase} />}
          {page === 'tournaments' && <TournamentsPage onRegister={handleRegister} />}
          {page === 'leaderboard' && <LeaderboardPage />}
          {page === 'rewards' && <RewardsPage loyaltyPoints={loyaltyPoints} onRedeem={handleRedeem} />}
          {page === 'wallet' && <WalletPage balance={walletBalance} onDeposit={handleDeposit} />}
          {page === 'support' && <SupportPage />}
        </PageTransition>

        {page === 'home' && <PromoMarquee />}
      </main>

      <Footer />
      <LiveActivityToast />
      <ToastStack toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}
