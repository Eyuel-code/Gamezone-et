import { useEffect, useState } from 'react';

/**
 * Thin gradient progress bar fixed to the top of the viewport.
 */
export default function ScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      setProgress(max > 0 ? (doc.scrollTop / max) * 100 : 0);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="fixed inset-x-0 top-0 z-[60] h-1">
      <div
        className="h-full bg-gradient-to-r from-primary-400 via-accent-400 to-gold-400 transition-[width] duration-150 ease-out"
        style={{ width: `${progress}%`, boxShadow: '0 0 12px rgba(17,189,247,0.6)' }}
      />
    </div>
  );
}
