import { Gamepad2, Flame, Crosshair, CircleDot, Trophy, Wallet, Gift, Headphones, ShieldCheck, Twitter, Youtube, Instagram, MessageCircle } from 'lucide-react';

export default function Footer() {
  const cols = [
    {
      title: 'Games',
      links: [
        { label: 'Free Fire', icon: Flame },
        { label: 'PUBG Mobile', icon: Crosshair },
        { label: 'EA Sports FC', icon: CircleDot },
      ],
    },
    {
      title: 'Platform',
      links: [
        { label: 'Tournaments', icon: Trophy },
        { label: 'Wallet', icon: Wallet },
        { label: 'Rewards', icon: Gift },
        { label: 'Support', icon: Headphones },
      ],
    },
  ];

  return (
    <footer className="relative border-t border-white/10 bg-ink-950">
      <div className="absolute inset-0 bg-grid opacity-20" />
      <div className="container-x relative py-14">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-primary-400 to-accent-500 text-ink-950">
                <Gamepad2 className="h-5 w-5" />
              </span>
              <span className="font-display text-lg font-bold text-white">
                GameZone<span className="text-primary-400">ET</span>
              </span>
            </div>
            <p className="mt-4 max-w-xs text-sm text-slate-400">
              Ethiopia's home for game top-ups, memberships, and esports tournaments. Pay in Birr, play instantly.
            </p>
            <div className="mt-5 flex gap-2.5">
              {[Twitter, Youtube, Instagram, MessageCircle].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 text-slate-400 transition-all hover:border-primary-300/50 hover:text-primary-300"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {cols.map((c) => (
            <div key={c.title} className="lg:col-span-2">
              <h4 className="font-display text-sm font-bold uppercase tracking-wider text-slate-300">{c.title}</h4>
              <ul className="mt-4 space-y-2.5">
                {c.links.map((l) => {
                  const Icon = l.icon;
                  return (
                    <li key={l.label}>
                      <a
                        href="#"
                        className="flex items-center gap-2 text-sm text-slate-400 transition-colors hover:text-white"
                      >
                        <Icon className="h-3.5 w-3.5" />
                        {l.label}
                      </a>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}

          <div className="lg:col-span-4">
            <h4 className="font-display text-sm font-bold uppercase tracking-wider text-slate-300">Stay in the loop</h4>
            <p className="mt-4 text-sm text-slate-400">Get tournament announcements and exclusive offers.</p>
            <form className="mt-4 flex gap-2" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="you@email.com"
                className="flex-1 rounded-xl border border-white/10 bg-ink-900/60 px-4 py-2.5 text-sm text-white placeholder:text-slate-600 focus:border-primary-400/50 focus:outline-none"
              />
              <button className="btn-primary px-4 py-2.5 text-sm">Subscribe</button>
            </form>
            <div className="mt-5 flex items-center gap-2 rounded-xl border border-success-400/20 bg-success-400/5 px-4 py-3 text-xs text-slate-400">
              <ShieldCheck className="h-4 w-4 text-success-400" />
              Licensed payment processor. All transactions secured & encrypted.
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs text-slate-500 sm:flex-row">
          <p>© 2026 GameZone ET. All rights reserved. Not affiliated with game publishers.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-slate-300">Terms</a>
            <a href="#" className="hover:text-slate-300">Privacy</a>
            <a href="#" className="hover:text-slate-300">Refund Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
