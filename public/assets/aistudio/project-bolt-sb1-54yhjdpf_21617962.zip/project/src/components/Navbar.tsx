import { useEffect, useState } from 'react';
import { Gamepad2, Menu, X, Wallet, Trophy, Home, Gift, Headphones, BarChart3, Coins } from 'lucide-react';
import { formatETB } from '@/data/catalog';
import type { PageId } from '@/hooks/useRouter';

const NAV: { id: PageId; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'topup', label: 'Top-Up', icon: Gamepad2 },
  { id: 'tournaments', label: 'Tournaments', icon: Trophy },
  { id: 'leaderboard', label: 'Leaderboard', icon: BarChart3 },
  { id: 'rewards', label: 'Rewards', icon: Gift },
  { id: 'wallet', label: 'Wallet', icon: Wallet },
  { id: 'support', label: 'Support', icon: Headphones },
];

export default function Navbar({
  currentPage,
  onNavigate,
  walletBalance,
  loyaltyPoints,
}: {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  walletBalance: number;
  loyaltyPoints: number;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (id: PageId) => {
    onNavigate(id);
    setOpen(false);
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass-strong shadow-card' : 'bg-transparent'
      }`}
    >
      <nav className="container-x flex h-16 items-center justify-between gap-4">
        <button onClick={() => go('home')} className="group flex items-center gap-2.5">
          <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-primary-400 to-accent-500 text-ink-950 shadow-glow transition-transform group-hover:scale-110">
            <Gamepad2 className="h-5 w-5" />
            <span className="absolute inset-0 rounded-xl ring-2 ring-primary-300/40 animate-pulse-ring" />
          </span>
          <span className="font-display text-lg font-bold tracking-tight text-white">
            GameZone<span className="text-primary-400">ET</span>
          </span>
        </button>

        <ul className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => {
            const Icon = n.icon;
            const active = currentPage === n.id;
            return (
              <li key={n.id}>
                <button
                  onClick={() => go(n.id)}
                  className={`group relative flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium transition-colors ${
                    active ? 'text-white' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Icon className={`h-4 w-4 transition-colors ${active ? 'text-primary-400' : ''}`} />
                  {n.label}
                  <span
                    className={`absolute inset-x-2 -bottom-0.5 h-0.5 rounded-full bg-gradient-to-r from-primary-400 to-accent-400 transition-all duration-300 ${
                      active ? 'opacity-100' : 'opacity-0 group-hover:opacity-50'
                    }`}
                  />
                </button>
              </li>
            );
          })}
        </ul>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => go('rewards')}
            className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm transition-colors hover:border-gold-400/50 hover:bg-white/10 sm:flex"
          >
            <Coins className="h-4 w-4 text-gold-400" />
            <span className="font-mono text-xs text-slate-300">{loyaltyPoints.toLocaleString()}</span>
          </button>
          <button
            onClick={() => go('wallet')}
            className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm transition-colors hover:border-primary-300/50 hover:bg-white/10 sm:flex"
          >
            <Wallet className="h-4 w-4 text-gold-400" />
            <span className="font-mono text-xs text-slate-300">{formatETB(walletBalance)}</span>
          </button>
          <button
            onClick={() => go('topup')}
            className="hidden btn-primary px-4 py-2 text-sm md:inline-flex"
          >
            Sign In
          </button>
          <button
            onClick={() => setOpen((o) => !o)}
            className="grid h-10 w-10 place-items-center rounded-lg border border-white/10 text-slate-200 lg:hidden"
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      <div
        className={`overflow-hidden transition-all duration-300 lg:hidden ${
          open ? 'max-h-[28rem]' : 'max-h-0'
        }`}
      >
        <ul className="container-x space-y-1 pb-5 pt-2">
          {NAV.map((n) => {
            const Icon = n.icon;
            const active = currentPage === n.id;
            return (
              <li key={n.id}>
                <button
                  onClick={() => go(n.id)}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    active ? 'bg-primary-400/10 text-white' : 'text-slate-300 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <Icon className={`h-4 w-4 ${active ? 'text-primary-400' : 'text-slate-500'}`} />
                  {n.label}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </header>
  );
}
