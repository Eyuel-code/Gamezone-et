import { useEffect, useState } from 'react';
import { Trophy, Zap } from 'lucide-react';
import { liveActivity } from '@/data/catalog';

/**
 * Rotating live-activity toast that cycles through recent purchases.
 */
export default function LiveActivityToast() {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const showTimer = setTimeout(() => setVisible(true), 2200);
    return () => clearTimeout(showTimer);
  }, []);

  useEffect(() => {
    if (!visible) return;
    const cycle = setInterval(() => {
      setIndex((i) => (i + 1) % liveActivity.length);
    }, 4500);
    return () => clearInterval(cycle);
  }, [visible]);

  const item = liveActivity[index];
  if (!item) return null;

  return (
    <div
      className={`fixed bottom-5 left-5 z-40 hidden max-w-xs transition-all duration-500 sm:block ${
        visible ? 'translate-y-0 opacity-100' : 'translate-y-6 opacity-0'
      }`}
    >
      <div className="glass-strong flex items-center gap-3 rounded-xl p-3 shadow-card">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary-400/15 text-primary-300">
          <Zap className="h-4 w-4" />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm text-slate-200">
            <span className="font-semibold text-white">{item.user}</span>{' '}
            <span className="text-slate-400">{item.action}</span>
          </p>
          <p className="flex items-center gap-1 text-xs text-slate-500">
            <Trophy className="h-3 w-3 text-gold-400" />
            {item.game} · {item.time}
          </p>
        </div>
      </div>
    </div>
  );
}
