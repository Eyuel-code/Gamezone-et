import { useEffect, useRef } from 'react';

/**
 * Floating 3D-ish geometric shapes that drift and rotate around a section.
 * Pure CSS transforms — no canvas. Decorative only.
 */
const shapes = [
  { left: '8%', top: '20%', size: 90, shape: 'cube', dur: 12, delay: 0 },
  { left: '82%', top: '15%', size: 70, shape: 'ring', dur: 14, delay: 1.5 },
  { left: '68%', top: '70%', size: 60, shape: 'cube', dur: 16, delay: 0.8 },
  { left: '18%', top: '78%', size: 80, shape: 'ring', dur: 18, delay: 2 },
  { left: '45%', top: '12%', size: 50, shape: 'cube', dur: 13, delay: 1 },
];

export default function FloatingShapes() {
  const reduce = useRef(
    typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );

  useEffect(() => {
    reduce.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      {shapes.map((s, i) => (
        <div
          key={i}
          className="absolute"
          style={{
            left: s.left,
            top: s.top,
            width: s.size,
            height: s.size,
            animation: reduce.current
              ? undefined
              : `float-slow ${s.dur}s ease-in-out ${s.delay}s infinite`,
          }}
        >
          {s.shape === 'cube' ? (
            <div
              className="relative h-full w-full"
              style={{
                transform: 'rotateX(55deg) rotateZ(45deg)',
                transformStyle: 'preserve-3d',
                animation: reduce.current ? undefined : `spin-slow ${s.dur * 2}s linear infinite`,
              }}
            >
              <div className="absolute inset-0 border border-primary-400/25 bg-primary-400/5 backdrop-blur-sm" />
              <div
                className="absolute inset-0 border border-primary-400/20 bg-primary-400/5"
                style={{ transform: 'translateZ(18px)' }}
              />
            </div>
          ) : (
            <div
              className="h-full w-full rounded-full border-2 border-accent-400/20"
              style={{
                animation: reduce.current ? undefined : `spin-slow ${s.dur}s linear infinite`,
                boxShadow: '0 0 30px -6px rgba(255,69,22,0.25) inset',
              }}
            >
              <div className="absolute inset-3 rounded-full border border-accent-400/15" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
