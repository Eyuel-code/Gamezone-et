import { useEffect, useState } from 'react';
import { CheckCircle2, X } from 'lucide-react';

export interface Toast {
  id: number;
  message: string;
}

export default function ToastStack({
  toasts,
  onDismiss,
}: {
  toasts: Toast[];
  onDismiss: (id: number) => void;
}) {
  return (
    <div className="fixed bottom-5 right-5 z-[80] flex flex-col gap-2.5">
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} onDismiss={onDismiss} />
      ))}
    </div>
  );
}

function ToastItem({ toast, onDismiss }: { toast: Toast; onDismiss: (id: number) => void }) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setExiting(true), 3800);
    const remove = setTimeout(() => onDismiss(toast.id), 4300);
    return () => {
      clearTimeout(timer);
      clearTimeout(remove);
    };
  }, [toast.id, onDismiss]);

  return (
    <div
      className={`glass-strong flex items-center gap-3 rounded-xl p-3.5 shadow-card transition-all duration-500 ${
        exiting ? 'translate-x-full opacity-0' : 'animate-slide-in-right'
      }`}
    >
      <CheckCircle2 className="h-5 w-5 shrink-0 text-success-400" />
      <span className="text-sm text-slate-200">{toast.message}</span>
      <button
        onClick={() => onDismiss(toast.id)}
        className="ml-2 text-slate-500 hover:text-white"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
