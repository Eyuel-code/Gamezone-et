import type { ReactNode } from 'react';
import { useEffect, useState, useRef } from 'react';

/**
 * Page transition wrapper — animates content in/out when the page key changes.
 * Creates a cross-fade + slide effect between pages.
 */
export default function PageTransition({ pageKey, children }: { pageKey: string; children: ReactNode }) {
  const [displayChildren, setDisplayChildren] = useState(children);
  const [phase, setPhase] = useState<'enter' | 'idle' | 'exit'>('enter');
  const prevKey = useRef(pageKey);

  useEffect(() => {
    if (pageKey !== prevKey.current) {
      setPhase('exit');
      const exitTimer = setTimeout(() => {
        setDisplayChildren(children);
        setPhase('enter');
        prevKey.current = pageKey;
      }, 250);
      return () => clearTimeout(exitTimer);
    } else {
      setDisplayChildren(children);
    }
  }, [pageKey, children]);

  useEffect(() => {
    if (phase === 'enter') {
      const t = setTimeout(() => setPhase('idle'), 550);
      return () => clearTimeout(t);
    }
  }, [phase]);

  const animClass =
    phase === 'exit'
      ? 'opacity-0 translate-y-6 scale-95 blur-sm'
      : phase === 'enter'
      ? 'opacity-100 translate-y-0 scale-100 blur-0'
      : 'opacity-100 translate-y-0 scale-100 blur-0';

  return (
    <div className={`transition-all duration-500 ease-out ${animClass}`} key={pageKey}>
      {displayChildren}
    </div>
  );
}
