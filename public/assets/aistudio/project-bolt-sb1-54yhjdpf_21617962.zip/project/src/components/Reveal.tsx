import type { ReactNode } from 'react';
import { useReveal } from '@/hooks/useMotion';

interface Props {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: 'div' | 'section' | 'li' | 'article';
  id?: string;
}

/**
 * Wraps children in a scroll-reveal fade/slide-up animation.
 */
export default function Reveal({ children, className = '', delay = 0, as = 'div', id }: Props) {
  const { ref, inView } = useReveal<HTMLDivElement>();
  const Tag = as as any;

  return (
    <Tag
      ref={ref}
      id={id}
      className={`${className} transition-all duration-700 ease-out ${
        inView ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}
