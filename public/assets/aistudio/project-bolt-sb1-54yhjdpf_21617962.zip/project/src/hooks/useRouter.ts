import { useState, useCallback, useEffect } from 'react';

export type PageId = 'home' | 'topup' | 'tournaments' | 'leaderboard' | 'rewards' | 'wallet' | 'support';

export const PAGES: { id: PageId; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'topup', label: 'Top-Up' },
  { id: 'tournaments', label: 'Tournaments' },
  { id: 'leaderboard', label: 'Leaderboard' },
  { id: 'rewards', label: 'Rewards' },
  { id: 'wallet', label: 'Wallet' },
  { id: 'support', label: 'Support' },
];

export function useRouter() {
  const [page, setPage] = useState<PageId>('home');
  const [direction, setDirection] = useState<'forward' | 'back'>('forward');

  const navigate = useCallback((to: PageId) => {
    setPage((prev) => {
      const fromIdx = PAGES.findIndex((p) => p.id === prev);
      const toIdx = PAGES.findIndex((p) => p.id === to);
      setDirection(toIdx >= fromIdx ? 'forward' : 'back');
      return to;
    });
  }, []);

  // Browser back/forward support via hash
  useEffect(() => {
    const onHash = () => {
      const hash = window.location.hash.replace('#/', '').replace('#', '') as PageId;
      const valid = PAGES.find((p) => p.id === hash);
      if (valid) setPage(hash);
    };
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const navigateWithHash = useCallback(
    (to: PageId) => {
      window.location.hash = `/${to}`;
      navigate(to);
    },
    [navigate]
  );

  return { page, direction, navigate: navigateWithHash };
}
