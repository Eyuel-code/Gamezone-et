// ===== Navbar shadow + back-to-top =====
const nav = document.querySelector(".navbar");
const toTop = document.getElementById("toTop");
window.addEventListener("scroll", () => {
  nav.classList.toggle("scrolled", window.scrollY > 40);
  if (toTop) toTop.style.display = window.scrollY > 400 ? "block" : "none";
});
if (toTop) toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

// ===== Active nav link =====
const page = location.pathname.split("/").pop() || "index.html";
document.querySelectorAll(".nav-link").forEach((a) => {
  if (a.getAttribute("href") === page) a.classList.add("active");
});

// ===== Reveal on scroll + animated bars/counters =====
const io = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (!e.isIntersecting) return;
    e.target.classList.add("visible");
    e.target.querySelectorAll(".progress-bar").forEach((b) => (b.style.width = b.dataset.value + "%"));
    e.target.querySelectorAll(".counter").forEach(countUp);
    io.unobserve(e.target);
  });
}, { threshold: 0.15 });
document.querySelectorAll(".reveal").forEach((el) => io.observe(el));

function countUp(el) {
  const target = +el.dataset.target;
  const suffix = el.dataset.suffix || "";
  let n = 0;
  const step = Math.max(1, Math.ceil(target / 60));
  const t = setInterval(() => {
    n += step;
    if (n >= target) { n = target; clearInterval(t); }
    el.textContent = n + suffix;
  }, 25);
}

// ===== Typing effect (home page) =====
const typed = document.getElementById("typed");
if (typed) {
  const words = ["Future Engineer", "Embedded Systems Builder", "Full-Stack Developer", "Bounce Juggler", "Chess Coach"];
  let w = 0, c = 0, del = false;
  (function tick() {
    const word = words[w];
    typed.textContent = word.slice(0, c);
    if (!del && c < word.length) c++;
    else if (!del) { del = true; return setTimeout(tick, 1400); }
    else if (c > 0) c--;
    else { del = false; w = (w + 1) % words.length; }
    setTimeout(tick, del ? 45 : 90);
  })();
}

// ===== Contact form (front-end only) =====
const form = document.getElementById("contactForm");
if (form) {
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!form.checkValidity()) { form.classList.add("was-validated"); return; }
    const d = new FormData(form);
    const subject = encodeURIComponent(d.get("subject"));
    const body = encodeURIComponent(`${d.get("message")}\n\n— ${d.get("name")} (${d.get("email")})`);
    window.location.href = `mailto:eyuelwondafrash014@gmail.com?subject=${subject}&body=${body}`;
    document.getElementById("formOk").classList.remove("d-none");
  });
}
