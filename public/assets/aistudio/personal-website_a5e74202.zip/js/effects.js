/* =====================================================
   EFFECTS ENGINE: cursor, particles, tilt, magnetic, etc.
   ===================================================== */
(() => {
  const fine = matchMedia("(hover: hover) and (pointer: fine)").matches;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- Preloader ---------- */
  const pre = document.createElement("div");
  pre.id = "preloader";
  pre.innerHTML = '<div class="ring"></div><p>Loading</p>';
  document.body.prepend(pre);
  const hidePre = () => pre.classList.add("done");
  window.addEventListener("load", () => setTimeout(hidePre, 450));
  setTimeout(hidePre, 3000); // safety

  /* ---------- Scroll progress + navbar hide/show ---------- */
  const bar = document.createElement("div");
  bar.id = "progress";
  document.body.appendChild(bar);
  const navEl = document.querySelector(".navbar");
  let lastY = 0;
  addEventListener("scroll", () => {
    const h = document.documentElement;
    bar.style.width = (h.scrollTop / (h.scrollHeight - h.clientHeight || 1)) * 100 + "%";
    const y = scrollY;
    const menuOpen = document.querySelector(".navbar-collapse.show");
    if (navEl && !menuOpen) navEl.classList.toggle("hide", y > lastY && y > 300);
    lastY = y;
  }, { passive: true });

  /* ---------- Cursor particle trail (normal cursor, tiny particles fall below it) ---------- */
  if (!reduce) {
    const cv = document.createElement("canvas");
    cv.id = "trail";
    document.body.appendChild(cv);
    const ctx = cv.getContext("2d");
    let W = 0, H = 0, running = false, lastX = null, lastY = null, hue = 30;
    const parts = [];
    const MAX = 450;

    const size = () => {
      const dpr = Math.min(devicePixelRatio || 1, 2);
      W = innerWidth; H = innerHeight;
      cv.width = W * dpr; cv.height = H * dpr;
      cv.style.width = W + "px"; cv.style.height = H + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    size(); addEventListener("resize", size);

    function emit(x, y, n, burst) {
      for (let i = 0; i < n; i++) {
        if (parts.length >= MAX) parts.shift();
        const a = Math.random() * Math.PI * 2;
        const sp = burst ? 1.5 + Math.random() * 3.5 : Math.random() * 0.9;
        hue = (hue + 3) % 360;
        parts.push({
          x: x + (Math.random() - 0.5) * 10,
          y: y + 10 + Math.random() * 8,                 // starts just below the pointer
          vx: burst ? Math.cos(a) * sp : (Math.random() - 0.5) * 1.4,
          vy: burst ? Math.sin(a) * sp : 0.3 + Math.random() * 1.1, // drifts downward
          r: 0.7 + Math.random() * 2.1,                  // tiny
          life: 1,
          decay: 0.012 + Math.random() * 0.02,
          h: hue + Math.random() * 40,
          tw: Math.random() * 6.28,
        });
      }
      if (!running) { running = true; requestAnimationFrame(tick); }
    }

    function tick() {
      ctx.clearRect(0, 0, W, H);
      ctx.globalCompositeOperation = "lighter";
      for (let i = parts.length - 1; i >= 0; i--) {
        const p = parts[i];
        p.vy += 0.025;                 // gentle gravity
        p.vx *= 0.985;
        p.x += p.vx; p.y += p.vy;
        p.life -= p.decay;
        p.tw += 0.35;
        if (p.life <= 0) { parts.splice(i, 1); continue; }
        const a = p.life * (0.65 + 0.35 * Math.sin(p.tw));   // twinkle
        // soft glow + bright core
        ctx.fillStyle = `hsla(${p.h},100%,65%,${a * 0.22})`;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r * 3, 0, 6.283); ctx.fill();
        ctx.fillStyle = `hsla(${p.h},100%,82%,${a})`;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r * p.life + 0.2, 0, 6.283); ctx.fill();
      }
      ctx.globalCompositeOperation = "source-over";
      if (parts.length) requestAnimationFrame(tick); else { running = false; ctx.clearRect(0, 0, W, H); }
    }

    function move(x, y) {
      if (lastX !== null) {
        const d = Math.hypot(x - lastX, y - lastY);
        if (d > 0.5) emit(x, y, Math.min(5, 1 + Math.floor(d / 10)));
      }
      lastX = x; lastY = y;
    }
    addEventListener("pointermove", (e) => { if (e.pointerType !== "touch") move(e.clientX, e.clientY); }, { passive: true });
    addEventListener("touchmove", (e) => { const t = e.touches[0]; if (t) move(t.clientX, t.clientY); }, { passive: true });
    addEventListener("pointerdown", (e) => emit(e.clientX, e.clientY, 26, true));
    document.addEventListener("mouseleave", () => { lastX = lastY = null; });
  }

  /* ---------- Particle network canvas in hero areas ---------- */
  if (!reduce) {
    document.querySelectorAll(".hero, .page-header, .hobby-hero").forEach((host) => {
      const cv = document.createElement("canvas");
      cv.className = "fx-canvas";
      host.prepend(cv);
      const ctx = cv.getContext("2d");
      let W, H, pts = [], mouse = { x: -999, y: -999 };
      const resize = () => {
        W = cv.width = host.offsetWidth; H = cv.height = host.offsetHeight;
        const n = Math.min(90, Math.floor((W * H) / 14000));
        pts = Array.from({ length: n }, () => ({
          x: Math.random() * W, y: Math.random() * H,
          vx: (Math.random() - 0.5) * 0.6, vy: (Math.random() - 0.5) * 0.6, r: 1 + Math.random() * 2,
        }));
      };
      resize(); addEventListener("resize", resize);
      host.addEventListener("mousemove", (e) => { const b = host.getBoundingClientRect(); mouse.x = e.clientX - b.left; mouse.y = e.clientY - b.top; });
      host.addEventListener("mouseleave", () => { mouse.x = mouse.y = -999; });
      let visible = true;
      new IntersectionObserver((en) => (visible = en[0].isIntersecting)).observe(host);
      (function draw() {
        requestAnimationFrame(draw);
        if (!visible) return;
        ctx.clearRect(0, 0, W, H);
        for (const p of pts) {
          p.x += p.vx; p.y += p.vy;
          if (p.x < 0 || p.x > W) p.vx *= -1;
          if (p.y < 0 || p.y > H) p.vy *= -1;
          const dx = p.x - mouse.x, dy = p.y - mouse.y, d = Math.hypot(dx, dy);
          if (d < 130) { p.x += (dx / d) * 2.2; p.y += (dy / d) * 2.2; }
          ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.283);
          ctx.fillStyle = "rgba(255,183,3,.85)"; ctx.fill();
        }
        for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
          const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
          if (d < 120) {
            ctx.strokeStyle = `rgba(76,201,240,${(1 - d / 120) * 0.45})`; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke();
          }
        }
        // lines to cursor
        for (const p of pts) {
          const d = Math.hypot(p.x - mouse.x, p.y - mouse.y);
          if (d < 160) { ctx.strokeStyle = `rgba(255,77,109,${(1 - d / 160) * 0.7})`; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(mouse.x, mouse.y); ctx.stroke(); }
        }
      })();
    });
  }

  /* ---------- Floating shapes in the home hero ---------- */
  const hero = document.querySelector(".hero");
  if (hero) ["s1", "s2", "s3", "s4"].forEach((c) => hero.appendChild(Object.assign(document.createElement("div"), { className: "shape " + c })));

  /* ---------- 3D tilt + spotlight on cards ---------- */
  if (fine && !reduce) {
    // delegated, so cards added later (GitHub repos) tilt too
    let cur = null;
    const TILT = ".card-x, .anime-card, .hero-art";
    document.addEventListener("mousemove", (e) => {
      const el = e.target.closest ? e.target.closest(TILT) : null;
      if (cur && cur !== el) { cur.style.transform = ""; cur = null; }
      if (!el) return;
      cur = el;
      const r = el.getBoundingClientRect();
      const x = e.clientX - r.left, y = e.clientY - r.top;
      el.style.setProperty("--mx", x + "px"); el.style.setProperty("--my", y + "px");
      const rx = ((y / r.height) - 0.5) * -12, ry = ((x / r.width) - 0.5) * 12;
      el.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-8px) scale(1.02)`;
    });
    document.addEventListener("mouseleave", () => { if (cur) { cur.style.transform = ""; cur = null; } });
  }

  /* ---------- Magnetic buttons + ripple ---------- */
  document.querySelectorAll(".btn-accent, .btn-outline-light-2, .social a, #toTop").forEach((b) => {
    if (fine && !reduce) {
      b.addEventListener("mousemove", (e) => {
        const r = b.getBoundingClientRect();
        b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.3}px, ${(e.clientY - r.top - r.height / 2) * 0.35}px)`;
      });
      b.addEventListener("mouseleave", () => (b.style.transform = ""));
    }
    b.addEventListener("click", (e) => {
      const r = b.getBoundingClientRect();
      const d = Math.max(r.width, r.height);
      const rp = document.createElement("span");
      rp.className = "ripple";
      rp.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
      b.appendChild(rp); setTimeout(() => rp.remove(), 700);
    });
  });

  /* ---------- Alternate reveal directions + stagger ---------- */
  document.querySelectorAll(".row").forEach((row) => {
    [...row.children].forEach((c, i) => {
      if (c.classList.contains("reveal")) c.style.transitionDelay = i * 0.12 + "s";
    });
  });
  document.querySelectorAll(".row > .reveal.col-lg-7, .row > .reveal.col-lg-6:first-child").forEach((c) => c.classList.add("from-left"));
  document.querySelectorAll(".row > .reveal.col-lg-5, .row > .reveal.col-lg-6:last-child").forEach((c) => c.classList.add("from-right"));

  /* ---------- Smooth page transitions ---------- */
  document.querySelectorAll('a[href$=".html"]').forEach((a) => {
    a.addEventListener("click", (e) => {
      if (e.ctrlKey || e.metaKey || a.target === "_blank") return;
      e.preventDefault();
      pre.classList.remove("done");
      setTimeout(() => (location.href = a.href), 350);
    });
  });
  addEventListener("pageshow", (e) => { if (e.persisted) hidePre(); });

  /* ---------- Parallax on hero avatar + background art ---------- */
  const avatar = document.querySelector(".avatar-ring");
  if (avatar && fine && !reduce) {
    addEventListener("mousemove", (e) => {
      const x = (e.clientX / innerWidth - 0.5) * 22, y = (e.clientY / innerHeight - 0.5) * 22;
      avatar.style.transform = `translate(${x}px, ${y}px)`;
    });
  }
  const heroBg = document.querySelector(".hobby-hero");
  if (heroBg && !reduce) addEventListener("scroll", () => { heroBg.style.backgroundPosition = `center ${scrollY * 0.35}px`; }, { passive: true });

  /* ---------- Title letter wave on hobby hero ---------- */
  document.querySelectorAll(".hobby-hero h1").forEach((h) => {
    let i = 0;
    h.childNodes.forEach((n) => {
      if (n.nodeType === 3) {
        const frag = document.createDocumentFragment();
        [...n.textContent].forEach((ch) => {
          const s = document.createElement("span");
          s.textContent = ch === " " ? " " : ch;
          s.style.cssText = `display:inline-block;animation:floaty 3s ease-in-out ${i++ * 0.12}s infinite`;
          frag.appendChild(s);
        });
        n.replaceWith(frag);
      }
    });
  });
})();
