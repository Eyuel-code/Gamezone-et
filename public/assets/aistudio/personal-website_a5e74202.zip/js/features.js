/* =====================================================
   FEATURES: theme toggle, flip cards, GitHub live data
   ===================================================== */
(() => {
  /* ---------- Theme (dark / light) ---------- */
  const root = document.documentElement;
  let saved = null;
  try { saved = localStorage.getItem("theme"); } catch (e) {}
  if (saved) root.setAttribute("data-theme", saved);

  const menu = document.querySelector(".navbar-nav");
  if (menu) {
    const li = document.createElement("li");
    li.className = "nav-item d-flex align-items-center";
    li.innerHTML = '<button class="theme-toggle" aria-label="Toggle dark and light theme"><i class="bi"></i></button>';
    menu.appendChild(li);
    const btn = li.querySelector("button"), icon = li.querySelector("i");
    const paint = () => { icon.className = "bi " + (root.getAttribute("data-theme") === "light" ? "bi-moon-stars-fill" : "bi-sun-fill"); };
    paint();
    btn.addEventListener("click", () => {
      const next = root.getAttribute("data-theme") === "light" ? "dark" : "light";
      root.setAttribute("data-theme", next);
      try { localStorage.setItem("theme", next); } catch (e) {}
      paint();
    });
  }

  /* ---------- Skip link ---------- */
  const skip = document.createElement("a");
  skip.className = "skip-link"; skip.href = "#main"; skip.textContent = "Skip to content";
  document.body.prepend(skip);
  const firstSection = document.querySelector("header, section");
  if (firstSection && !firstSection.id) firstSection.id = "main";

  /* ---------- Flip cards: tap to flip on touch devices ---------- */
  document.querySelectorAll(".flip").forEach((f) => {
    f.addEventListener("click", () => f.classList.toggle("flipped"));
  });

  /* ---------- GitHub live data (projects page) ---------- */
  const grid = document.getElementById("repoGrid");
  if (!grid) return;
  const USER = "Eyuel-code";
  const colors = { JavaScript: "#f1e05a", HTML: "#e34c26", CSS: "#563d7c", Python: "#3572A5", "C++": "#f34b7d", C: "#555555", TypeScript: "#3178c6", Java: "#b07219", Shell: "#89e051" };
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const count = (el, n) => {
    let v = 0; const step = Math.max(1, Math.ceil(n / 40));
    const t = setInterval(() => { v += step; if (v >= n) { v = n; clearInterval(t); } el.textContent = v; }, 30);
  };

  const fail = () => {
    grid.innerHTML = '<div class="col-12 text-center text-muted-2">Could not load repositories right now. ' +
      '<a href="https://github.com/' + USER + '?tab=repositories" target="_blank" rel="noopener">Open my GitHub</a> to see them.</div>';
  };

  Promise.all([
    fetch(`https://api.github.com/users/${USER}`).then((r) => { if (!r.ok) throw 0; return r.json(); }),
    fetch(`https://api.github.com/users/${USER}/repos?per_page=100&sort=updated`).then((r) => { if (!r.ok) throw 0; return r.json(); }),
  ]).then(([user, repos]) => {
    const own = repos.filter((r) => !r.fork);
    const stars = own.reduce((a, r) => a + r.stargazers_count, 0);
    count(document.getElementById("ghRepos"), user.public_repos ?? own.length);
    count(document.getElementById("ghFollowers"), user.followers ?? 0);
    count(document.getElementById("ghStars"), stars);

    const top = own.sort((a, b) => b.stargazers_count - a.stargazers_count || new Date(b.pushed_at) - new Date(a.pushed_at)).slice(0, 6);
    if (!top.length) return (grid.innerHTML = '<div class="col-12 text-center text-muted-2">No public repositories yet.</div>');

    grid.innerHTML = top.map((r, i) => `
      <div class="col-md-6 col-lg-4 reveal visible" style="transition-delay:${i * 0.1}s">
        <a class="card-x repo-card d-block text-reset" href="${esc(r.html_url)}" target="_blank" rel="noopener">
          <h5><i class="bi bi-journal-code"></i>${esc(r.name)}</h5>
          <p class="text-muted-2">${esc(r.description) || "No description yet."}</p>
          <div class="repo-meta">
            ${r.language ? `<span><span class="lang-dot" style="background:${colors[r.language] || "#4cc9f0"}"></span>${esc(r.language)}</span>` : ""}
            <span><i class="bi bi-star-fill"></i> ${r.stargazers_count}</span>
            <span><i class="bi bi-diagram-2-fill"></i> ${r.forks_count}</span>
            <span><i class="bi bi-clock-history"></i> ${new Date(r.pushed_at).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</span>
          </div>
        </a>
      </div>`).join("");
  }).catch(fail);
})();
