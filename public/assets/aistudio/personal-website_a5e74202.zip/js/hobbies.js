// Lightbox: show the clicked anime image large
document.querySelectorAll(".anime-card").forEach((card) => {
  card.addEventListener("click", () => {
    document.getElementById("lightboxImg").src = card.dataset.img;
  });
});

// Decorative chessboard (a few pieces in a famous-looking position)
const board = document.getElementById("board");
if (board) {
  const pieces = {
    "0,4": ["♚", "b"], "1,0": ["♟", "b"], "1,5": ["♟", "b"], "2,2": ["♞", "b"], "0,2": ["♝", "b"],
    "6,3": ["♙", "w"], "6,6": ["♙", "w"], "5,4": ["♘", "w"], "7,4": ["♔", "w k"], "4,2": ["♗", "w"], "7,0": ["♖", "w"], "3,3": ["♕", "w"],
  };
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const sq = document.createElement("div");
      sq.className = (r + c) % 2 === 0 ? "l" : "d";
      const p = pieces[`${r},${c}`];
      if (p) { sq.textContent = p[0]; sq.className += " " + p[1]; }
      board.appendChild(sq);
    }
  }
}
