# Personal Website

Multi-page responsive portfolio built with HTML, Bootstrap 5 (CDN), custom CSS and vanilla JavaScript.

## Structure
```
personal-website/
├── index.html        Home (hero, stats, services, hobbies teaser)
├── about.html        Story, skills, education timeline
├── projects.html     Project cards
├── activities.html   Leadership timeline
├── hobbies.html      Chess, Anime gallery, Circus, Music
├── contact.html      Contact form (opens email app)
├── css/
│   ├── style.css     Global theme
│   ├── effects.css   Cursor, gradients, hover + motion effects
│   ├── features.css  Hero art, theme toggle, flip cards, GitHub cards
│   └── hobbies.css   Hobbies page styles
├── js/
│   ├── main.js       Navbar, reveal animations, typing effect, form
│   ├── effects.js    Custom cursor, particles, tilt, magnetic buttons
│   ├── features.js   Dark/light toggle, flip cards, live GitHub repos
│   └── hobbies.js    Lightbox + chessboard
└── assets/img/
    ├── hero-luffy.jpg  Hero artwork (cropped from the original, full quality)
    └── anime/        Anime artwork
```

## Before you submit
1. Edit the anime list in `hobbies.html` so it only shows what you watched.
2. Check the skill percentages and numbers on the About page.
3. Open `index.html` in a browser (needs internet for Bootstrap, fonts and the live GitHub section).

Artwork credit: the anime images are fan art by their original artists.
